package com.righttek.ts.solicitarprestamo.controller.impl;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.righttek.gotalent.comun.exception.BusinessException;
import com.righttek.gotalent.comun.utilitarios.DataValidator;
import com.righttek.gotalent.comun.utilitarios.RespuestaType;
import com.righttek.gotalent.modelo_canonico.SolicitudPrestamoType;
import com.righttek.ts.solicitarprestamo.controller.contract.ISolicitarPrestamoController;
import com.righttek.ts.solicitarprestamo.service.contract.ISolicitarPrestamoSvc;

/**
 * 
 * @author osarcos
 *
 */
@RestController
@RequestMapping("/api/ts")
public class SolicitarPrestamoController implements ISolicitarPrestamoController{

	private static final Logger LOG = org.slf4j.LoggerFactory.getLogger(SolicitarPrestamoController.class);
	
	@Autowired
	ISolicitarPrestamoSvc solicitarPrestamoSvc;
	
	@Override
	public ResponseEntity<?> solicitarPrestamo(@Valid SolicitudPrestamoType solicitudPrestamoType) {

		ResponseEntity<RespuestaType> response;
		RespuestaType respuesta = new RespuestaType();
		
		try {
			LOG.info("INICIA PROCESO DE SOLICITAR PRESTAMO");
			respuesta = (RespuestaType) solicitarPrestamoSvc.solicitarPrestamo(solicitudPrestamoType);
			response = new ResponseEntity<RespuestaType>(respuesta, HttpStatus.OK);
			
		}catch (BusinessException e) {
			LOG.error("ERROR DE NEGOCIO AL SOLICITAR PRESTAMO: {}\n{}", e.getMessage(), e.getLocalizedMessage());
			response = DataValidator.validarResultado(e);
			
		}catch (Exception e) {
			LOG.error("EXCEPCION AL SOLICITAR PRESTAMO: {} \nen: {}", e.getMessage(), e.getLocalizedMessage());
			respuesta.setCodigoRespuesta("9999");
			respuesta.setDescripcion("ERROR EN EL PROCESAMIENTO DE LA SOLICITUD DE PRESTAMO");
			return new ResponseEntity<RespuestaType>(respuesta, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		LOG.info("FINALIZA PROCESO DE SOLICITAR PRESTAMO");
		return response;
	}

	@Override
	public ResponseEntity<?> validarSolicitudPrestamo(String empleadoId, Double valorPrestamo, Integer cuotasPrestamo) {
		
		ResponseEntity<RespuestaType> response;
		RespuestaType respuestaType = new RespuestaType();
		
		try {
			LOG.info("INICIA VALIDAR SOLICITUD ANTICIPO");
			Boolean result = solicitarPrestamoSvc.validarSolicitudPrestamo(empleadoId, valorPrestamo, cuotasPrestamo);
			return new ResponseEntity<Boolean>(result, HttpStatus.OK);
		}catch (BusinessException e) {
			LOG.error("ERROR DE NEGOCIO VALIDAR SOLICITUD ANTICIPO");
			response = DataValidator.validarResultado(e);
		} catch (Exception e) {
			LOG.error("EXCEPCION VALIDAR SOLICITUD ANTICIPO: {} \nen: {}", e.getMessage(), e.getLocalizedMessage());
			respuestaType.setCodigoRespuesta("9999");
			respuestaType.setDescripcion("ERROR EN EL PROCESAMIENTO VALIDAR SOLICITUD ANTICIPO");
			return new ResponseEntity<RespuestaType>(respuestaType, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		LOG.info("FINALIZA VALIDAR SOLICITUD ANTICIPO");
		return response;
	
	}

	@Override
	public ResponseEntity<?> registrarSolicitudPrestamo(@Valid SolicitudPrestamoType solicitudPrestamoType) {
		
		ResponseEntity<RespuestaType> response;
		RespuestaType respuestaType = new RespuestaType();
		
		try {
			LOG.info("INICIA REGISTRAR SOLICITUD PRESTAMO");
			Boolean result = solicitarPrestamoSvc.registrarSolicitudPrestamo(solicitudPrestamoType);
			return new ResponseEntity<Boolean>(result, HttpStatus.OK);
			
		}catch (BusinessException e) {
			LOG.error("ERROR DE NEGOCIO REGISTRAR SOLICITUD PRESTAMO: {}\n{}", e.getMessage(), e.getLocalizedMessage());
			response =  DataValidator.validarResultado(e);
		
		} catch (Exception e) {
			LOG.error("EXCEPCION REGISTRAR SOLICITUD PRESTAMO: {} \nen: {}", e.getMessage(), e.getLocalizedMessage());
			respuestaType.setCodigoRespuesta("9999");
			respuestaType.setDescripcion("ERROR EN EL PROCESAMIENTO REGISTRAR SOLICITUD PRESTAMO");
			return new ResponseEntity<RespuestaType>(respuestaType, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		LOG.info("FINALIZA REGISTRAR SOLICITUD PRESTAMO");
		return response;
		
	}

}
