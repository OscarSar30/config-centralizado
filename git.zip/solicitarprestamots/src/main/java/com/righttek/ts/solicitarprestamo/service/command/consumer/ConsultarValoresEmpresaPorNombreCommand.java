/**
 * 
 */
package com.righttek.ts.solicitarprestamo.service.command.consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.righttek.gotalent.comun.exception.BusinessException;
import com.righttek.gotalent.comun.exception.TipoError;
import com.righttek.gotalent.comun.patrones.command.ICommand;
import com.righttek.gotalent.comun.patrones.command.IParam;
import com.righttek.gotalent.modelo_canonico.ParametrosEmpresaType;
import com.righttek.ts.solicitarprestamo.constants.SolicitarPrestamoConstants;
import com.righttek.ts.solicitarprestamo.controller.dto.GenericStringParam;

/**
 * @author osarcos
 * 
 * COMANDO UTILIZADO PARA CONSULTAR LOS VALORES CONFIGURABLES QUE TIENE UNA EMPRESA PARA VERIFICAR
 * PARAMETROS QUE ESTE CONFIGURADO PARA DICHA EMPRESA
 *
 */
@Component
public class ConsultarValoresEmpresaPorNombreCommand implements ICommand{

	private static final Logger LOG = LoggerFactory.getLogger(ConsultarValoresEmpresaPorNombreCommand.class);
	
	@Value("${uri.valoresConfigurables}")
	private String hostService;
	
	@Override
	public Object execute(IParam parametro) throws BusinessException {
		
		LOG.info("INICIA COMMAND CONSULTAR VALORES EMPRESA POR NOMBRE");
		
		GenericStringParam genericParam = (GenericStringParam) parametro;		
		
		/* 
		 * DECLARAMOS LO OBJETOS QUE USAREMOS PARA DEFINIR EL REQUEST 
		 * Y REALIZAR EL LLAMADO A AL ENDPOINT DE LA API CORRESPONDIENTE
		 */
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<ParametrosEmpresaType> response;
		
		try {
			/* REALIZAMOS EL LLAMADO A LA CAPACIDAD "consultarParametrosEmpresaPorNombre" DEL SERVICIO "ValoresConfigurablesES" */
			response = restTemplate.exchange(
					hostService.concat(SolicitarPrestamoConstants.CONSULTAR_VALORES_EMPRESA_POR_NOMBRE),
					HttpMethod.GET, null, 
					new ParameterizedTypeReference<ParametrosEmpresaType>() {},genericParam.getValues().get("empresaId"), genericParam.getValues().get("nombreParametro"));
		} catch (HttpStatusCodeException e) {
			LOG.error("HTTP EXCEPCION COMMAND CONSULTAR VALORES EMPRESA POR NOMBRE: {}", e.getMessage(), e.getStackTrace());	
			throw new BusinessException(String.format(SolicitarPrestamoConstants.MENSAJE_ERROR_CONSULTA,"PARAMETROS DE EMPRESA"), TipoError.FUENTE_DE_DATOS);
		}
		
		LOG.info("FINALIZA COMMAND CONSULTAR VALORES EMPRESA POR NOMBRE");
		return response.getBody();
		
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		
	}

}
