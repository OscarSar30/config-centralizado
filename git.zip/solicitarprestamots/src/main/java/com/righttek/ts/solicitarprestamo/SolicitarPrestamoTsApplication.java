package com.righttek.ts.solicitarprestamo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SolicitarPrestamoTsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SolicitarPrestamoTsApplication.class, args);
	}

}
