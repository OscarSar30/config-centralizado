/**
 * 
 */
package com.righttek.ts.solicitarprestamo.service.command.consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.righttek.gotalent.comun.exception.BusinessException;
import com.righttek.gotalent.comun.exception.TipoError;
import com.righttek.gotalent.comun.patrones.command.ICommand;
import com.righttek.gotalent.comun.patrones.command.IParam;
import com.righttek.gotalent.modelo_canonico.RolType;
import com.righttek.ts.solicitarprestamo.constants.SolicitarPrestamoConstants;
import com.righttek.ts.solicitarprestamo.controller.dto.GenericStringParam;

/**
 * @author osarcos
 * 
 * COMANDO UTILIZADO PARA CONSULTAR EL ROL POR MEDIO DEL EMPLEADO ID Y EMPRESA ID PARA CONTINUAR CON EL FLUJO
 *
 */
@Component
public class ConsultarRolPorIdCommand implements ICommand{

	private static final Logger LOG = LoggerFactory.getLogger(ConsultarEmpleadoPorIdCommand.class);
	
	@Value("${uri.rol}")
	private String hostService;
	
	@Override
	public Object execute(IParam parametro) throws BusinessException {

		LOG.info("INICIA COMMAND CONSULTAR ROL POR EMPLEADO ID Y EMPRESA ID");
		
		GenericStringParam genericParam = (GenericStringParam) parametro;
		
		/* 
		 * DECLARAMOS LO OBJETOS QUE USAREMOS PARA DEFINIR EL REQUEST 
		 * Y REALIZAR EL LLAMADO A AL ENDPOINT DE LA API CORRESPONDIENTE
		 */
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<RolType> response;
		
		try {
			/* REALIZAMOS EL LLAMADO A LA CAPACIDAD "consultarRolPorId" DEL SERVICIO "RolES" */
			response = restTemplate.exchange(
					hostService.concat(SolicitarPrestamoConstants.CONSULTAR_ROL_POR_ID),
					HttpMethod.GET, null, 
					new ParameterizedTypeReference<RolType>() {},genericParam.getValues().get("empresaId"), genericParam.getValues().get("rolId"));
		} catch (HttpStatusCodeException e) {
			LOG.error("HTTP EXCEPCION COMMAND CONSULTAR ROL POR EMPRESA ID Y ROL ID: {}", e.getMessage(), e.getStackTrace());
			throw new BusinessException(String.format(SolicitarPrestamoConstants.MENSAJE_ERROR_CONSULTA,"ROL POR EMPRESA ID Y ROL ID"),TipoError.FUENTE_DE_DATOS);
		}
		
		LOG.info("FINALIZA COMMAND CONSULTAR ROL POR EMPLEADO ID Y EMPRESA ID");
		return response.getBody();
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		
	}

}
