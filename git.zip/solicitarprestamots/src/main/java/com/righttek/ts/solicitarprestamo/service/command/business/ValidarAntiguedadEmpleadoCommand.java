package com.righttek.ts.solicitarprestamo.service.command.business;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.righttek.gotalent.comun.exception.BusinessException;
import com.righttek.gotalent.comun.exception.TipoError;
import com.righttek.gotalent.comun.patrones.command.ICommand;
import com.righttek.gotalent.comun.patrones.command.IParam;
import com.righttek.ts.solicitarprestamo.constants.SolicitarPrestamoConstants;
import com.righttek.ts.solicitarprestamo.controller.dto.ValidarAntiguedadEmpleadoDTO;
import com.righttek.ts.solicitarprestamo.utils.SolicitarPrestamoValidator;

/**
 * @author osarcos
 * 
 * COMANDO QUE USAREMOS PARA VALIDAR TIEMPO DE ANTIGUEDAD DEL EMPLEADO SEGÚN PARAMETROS CONFIGURADOS PARA LA EMPRESA
 * 
 */
@Component
public class ValidarAntiguedadEmpleadoCommand implements ICommand{

	private static final Logger LOG = LoggerFactory.getLogger(ValidarAntiguedadEmpleadoCommand.class);
	
	@Override
	public Object execute(IParam parametro) throws BusinessException {
		
		LOG.info("INICIA COMMAND VALIDAR ANTIGUEDAD EMPLEADO");
		
		Date fechaActual = new Date();
		ValidarAntiguedadEmpleadoDTO validarAntiguedadEmpleadoParam = (ValidarAntiguedadEmpleadoDTO) parametro;
		
		/* 
		 * OBTENEMOS EL TIEMPO DE ANTIGÜEDAD EN MESES DEL EMPLEADO EL CUAL SE OBTUVO 
		 * AL CONSULTAR AL EMPLEADO
		 */
		int antiguedadEmpleadoMeses = SolicitarPrestamoValidator.obtenerTiempoEnMeses(validarAntiguedadEmpleadoParam.getEmpleado(), fechaActual);
				
		/* 
		 * VALIDAMOS SI LA ANTIGÜEDAD DEL EMPLEADO ES MAYOR A LA ANTIGÜEDAD MÍNIMA REQUERIDA SEGÚN
		 * VALOR PARAMETRIZADO
		 */
		if (antiguedadEmpleadoMeses <= validarAntiguedadEmpleadoParam.getTiempoAntiguedad()) {
			LOG.info("FINALIZA COMMAND VALIDAR ANTIGUEDAD EMPLEADO POR BUSINESSEXCEPTION");
			throw new BusinessException(SolicitarPrestamoConstants.ANTIGUEDAD,TipoError.LOGICA_NEGOCIO);
		}

		LOG.info("FINALIZA COMMAND VALIDAR ANTIGUEDAD EMPLEADO");
		return null;
		
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		
	}

}
