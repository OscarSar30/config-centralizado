package com.righttek.ts.solicitarprestamo.controller.dto;

import com.righttek.gotalent.comun.patrones.command.IParam;
import com.righttek.gotalent.modelo_canonico.EmpleadoLegacyType;

/**
 * 
 * @author osarcos
 *
 */
public class ValidarAntiguedadEmpleadoDTO implements IParam{

	private Integer tiempoAntiguedad;
	private EmpleadoLegacyType empleado;
	
	
	public Integer getTiempoAntiguedad() {
		return tiempoAntiguedad;
	}
	
	public void setTiempoAntiguedad(Integer tiempoAntiguedad) {
		this.tiempoAntiguedad = tiempoAntiguedad;
	}
	
	public EmpleadoLegacyType getEmpleado() {
		return empleado;
	}
	
	public void setEmpleado(EmpleadoLegacyType empleado) {
		this.empleado = empleado;
	}
	
}
