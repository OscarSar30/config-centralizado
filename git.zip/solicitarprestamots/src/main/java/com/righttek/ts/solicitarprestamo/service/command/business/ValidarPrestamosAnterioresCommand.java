/**
 * 
 */
package com.righttek.ts.solicitarprestamo.service.command.business;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.righttek.gotalent.comun.exception.BusinessException;
import com.righttek.gotalent.comun.exception.TipoError;
import com.righttek.gotalent.comun.patrones.command.ICommand;
import com.righttek.gotalent.comun.patrones.command.IParam;
import com.righttek.ts.solicitarprestamo.constants.SolicitarPrestamoConstants;
import com.righttek.ts.solicitarprestamo.controller.dto.ValidarPrestamosAnterioresDTO;

/**
 * @author osarcos
 * 
 * COMANDO QUE USAREMOS PARA VALIDAR SI EL EMPLEADO QUE SE CONSULTO A LEGADO POSEE PRESTAMOS PENDIENTES CON LA EMPRESA
 *
 */
@Component
public class ValidarPrestamosAnterioresCommand implements ICommand{

	private static final Logger LOG = LoggerFactory.getLogger(ValidarAntiguedadEmpleadoCommand.class);
	
	@Override
	public Object execute(IParam parametro) throws BusinessException {
		
		LOG.info("INICIA COMMAND VALIDAR PRESTAMOS ANTERIORES");
		
		ValidarPrestamosAnterioresDTO validarPrestamosAnterioresParam = (ValidarPrestamosAnterioresDTO) parametro;
		
		/* 
		 * VALIDAMOS SI LA LISTA DE PRESTAMOS QUE POSEE EL EMPLEADO ES NULA ASIGNAMOS UN VALOR POR DEFECTO DE CERO
		 * DE LO CONTRARIO CAPTURAMOS EL TAMAÑO DE LA LISTA 
		 */
		int cantidadPrestamos = validarPrestamosAnterioresParam.getListPrestamo() == null ? 0 : validarPrestamosAnterioresParam.getListPrestamo().size();
				
		/* 
		 * VALIDAMOS SI EL TOTAL DE PRESTAMOS DEL EMPLEADO ES MAYOR A CERO, SI LO ES SALTA BUSINESSEXCEPTION, CASO CONTRARIO
		 * CONTINUA SU FLUJO
		 */
		if (cantidadPrestamos > 0) {
			LOG.info("FINALIZA COMMAND VALIDAR PRESTAMOS ANTERIORES POR BUSINESSEXCEPTION");
			throw new BusinessException(SolicitarPrestamoConstants.POSEE_PRESTAMOS_PENDIENTES,TipoError.LOGICA_NEGOCIO);
		}

		LOG.info("FINALIZA COMMAND VALIDAR PRESTAMOS ANTERIORES");
		return null;
		
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		
	}

}
