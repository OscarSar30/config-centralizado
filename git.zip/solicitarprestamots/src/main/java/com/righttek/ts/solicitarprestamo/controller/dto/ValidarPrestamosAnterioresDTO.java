/**
 * 
 */
package com.righttek.ts.solicitarprestamo.controller.dto;

import java.util.List;

import com.righttek.gotalent.comun.patrones.command.IParam;
import com.righttek.gotalent.modelo_canonico.PrestamoType;

/**
 * @author osarcos
 *
 */
public class ValidarPrestamosAnterioresDTO implements IParam{
	
	private List<PrestamoType> listPrestamo;

	/**
	 * @return the listPrestamo
	 */
	public List<PrestamoType> getListPrestamo() {
		return listPrestamo;
	}

	/**
	 * @param listPrestamo the listPrestamo to set
	 */
	public void setListPrestamo(List<PrestamoType> listPrestamo) {
		this.listPrestamo = listPrestamo;
	}

}
