package com.righttek.ts.solicitarprestamo.controller.dto;

import com.righttek.gotalent.comun.patrones.command.IParam;
import com.righttek.gotalent.modelo_canonico.CorreoType;

public class CorreoParam extends CorreoType implements IParam{

}
