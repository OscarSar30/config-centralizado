package com.righttek.ts.solicitarprestamo.service.command.business;

import org.springframework.stereotype.Component;

import com.righttek.gotalent.comun.exception.BusinessException;
import com.righttek.gotalent.comun.patrones.command.ICommand;
import com.righttek.gotalent.comun.patrones.command.IParam;
import com.righttek.ts.solicitarprestamo.controller.dto.CorreoParam;
import com.righttek.ts.solicitarprestamo.controller.dto.VincularParametrosNotificacionDTO;

/**
 * @author osarcos
 * 
 * COMANDO QUE USAREMOS PARA VINCULAR LOS PARAMETROS DE LA PLANTILLA DE NOTIFICACIONES
 * CON SU VALORES CORREPONDIENTES Y ADEMAS YA DEFINIR EL OBJETO DE CORREO ELECTRONICO QUE NECESITAMOS
 *
 */
@Component
public class VincularParametrosNotificacionCommand implements ICommand{

	@Override
	public Object execute(IParam parametro) throws BusinessException {
		
		VincularParametrosNotificacionDTO parametrosNotificacionDTO = (VincularParametrosNotificacionDTO) parametro;
		
		/*CAPTURAMOS LA PLANTILLAS DE NOTIFICACION EN UNA VARIABLE*/
		String plantillaNotificacion = parametrosNotificacionDTO.getPlantillaNotificacionType().getValor();
		
		/*EN CASO DE QUE ESTA NO SEA NULL PROCEDEMOS A VINCULAR LOS DATOS EN LA PLANTILLA*/
		if( plantillaNotificacion != null) {

			plantillaNotificacion = plantillaNotificacion.replace("&nombreSolicitante", parametrosNotificacionDTO.getNombreEmpleado())
					.replace("&estadoSolicitud", parametrosNotificacionDTO.getSolicitudPrestamoType().getEstado().getValue());
		}

		/*
		 * DECLARAMOS UN OBJETO "CORREOPARAM" Y DEFINIMOS SU DATOS DE MENSAJE, ASUNTO Y
		 * DESTINATARIO
		 */
		CorreoParam correoParam = new CorreoParam();	
		correoParam.setMensaje(plantillaNotificacion);
		correoParam.setAsunto(parametrosNotificacionDTO.getPlantillaNotificacionType().getDetalle());
		correoParam.setPara(parametrosNotificacionDTO.getSolicitudPrestamoType().getUsuarioCreacion());
		return correoParam;
	
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		
	}

}
