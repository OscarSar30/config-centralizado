/**
 * 
 */
package com.righttek.ts.solicitarprestamo.service.command.consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.righttek.gotalent.comun.exception.BusinessException;
import com.righttek.gotalent.comun.exception.TipoError;
import com.righttek.gotalent.comun.patrones.command.ICommand;
import com.righttek.gotalent.comun.patrones.command.IParam;
import com.righttek.gotalent.modelo_canonico.UsuarioType;
import com.righttek.ts.solicitarprestamo.constants.SolicitarPrestamoConstants;
import com.righttek.ts.solicitarprestamo.controller.dto.SolicitudPrestamoParam;

/**
 * @author osarcos
 * 
 * COMANDO UTILIZADO PARA CONSULTAR EL USUARIO POR MEDIO DEL EMPLEADO ID PARA OBTENER EL ROL ID PARA CONTINUAR FLUJO
 *
 */
@Component
public class ConsultarUsuarioPorEmpleadoIdCommand implements ICommand{

	private static final Logger LOG = LoggerFactory.getLogger(ConsultarEmpleadoPorIdCommand.class);
	
	@Value("${uri.usuario}")
	private String hostService;
	
	@Override
	public Object execute(IParam parametro) throws BusinessException {

		LOG.info("INICIA COMMAND CONSULTAR USUARIO POR EMPLEADO ID");
		
		SolicitudPrestamoParam solicitudPrestamo = (SolicitudPrestamoParam) parametro;
		
		/* 
		 * DECLARAMOS LO OBJETOS QUE USAREMOS PARA DEFINIR EL REQUEST 
		 * Y REALIZAR EL LLAMADO A AL ENDPOINT DE LA API CORRESPONDIENTE
		 */
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<UsuarioType> response;
		
		try {
			/* REALIZAMOS EL LLAMADO A LA CAPACIDAD "consultarUsuarioPorEmpleadoId" DEL SERVICIO "UsuarioES" */
			response = restTemplate.exchange(
					hostService.concat(SolicitarPrestamoConstants.CONSULTAR_USUARIO_POR_EMPLEADO_ID),
					HttpMethod.GET, null, 
					new ParameterizedTypeReference<UsuarioType>() {},solicitudPrestamo.getEmpleadoId());
		} catch (HttpStatusCodeException e) {
			LOG.error("HTTP EXCEPCION COMMAND CONSULTAR USUARIO POR EMPLEADO ID: {}", e.getMessage(), e.getStackTrace());
			throw new BusinessException(String.format(SolicitarPrestamoConstants.MENSAJE_ERROR_CONSULTA,"USUARIO POR EMPLEADO ID"),TipoError.FUENTE_DE_DATOS);
		}
		
		LOG.info("FINALIZA COMMAND CONSULTAR EMPLEADO POR ID");
		return response.getBody();
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		
	}

}
