/**
 * 
 */
package com.righttek.ts.solicitarprestamo.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.righttek.gotalent.comun.exception.BusinessException;
import com.righttek.gotalent.comun.utilitarios.RespuestaType;
import com.righttek.gotalent.modelo_canonico.EmpleadoLegacyType;
import com.righttek.gotalent.modelo_canonico.EstadoSolicitud;
import com.righttek.gotalent.modelo_canonico.ParametrosEmpresaType;
import com.righttek.gotalent.modelo_canonico.PlantillaNotificacionType;
import com.righttek.gotalent.modelo_canonico.PrestamoType;
import com.righttek.gotalent.modelo_canonico.RolType;
import com.righttek.gotalent.modelo_canonico.SolicitudPrestamoType;
import com.righttek.gotalent.modelo_canonico.UsuarioType;
import com.righttek.ts.solicitarprestamo.constants.SolicitarPrestamoConstants;
import com.righttek.ts.solicitarprestamo.controller.dto.CorreoParam;
import com.righttek.ts.solicitarprestamo.controller.dto.GenericStringParam;
import com.righttek.ts.solicitarprestamo.controller.dto.SolicitudPrestamoParam;
import com.righttek.ts.solicitarprestamo.controller.dto.ValidarAntiguedadEmpleadoDTO;
import com.righttek.ts.solicitarprestamo.controller.dto.ValidarPrestamoDTO;
import com.righttek.ts.solicitarprestamo.controller.dto.ValidarPrestamosAnterioresDTO;
import com.righttek.ts.solicitarprestamo.controller.dto.VincularParametrosNotificacionDTO;
import com.righttek.ts.solicitarprestamo.service.command.business.ValidarAntiguedadEmpleadoCommand;
import com.righttek.ts.solicitarprestamo.service.command.business.ValidarPrestamoCommand;
import com.righttek.ts.solicitarprestamo.service.command.business.ValidarPrestamosAnterioresCommand;
import com.righttek.ts.solicitarprestamo.service.command.business.VincularParametrosNotificacionCommand;
import com.righttek.ts.solicitarprestamo.service.command.consumer.ConsultarEmpleadoPorIdCommand;
import com.righttek.ts.solicitarprestamo.service.command.consumer.ConsultarPlantillaNotificacionEmpresaPorNombreCommand;
import com.righttek.ts.solicitarprestamo.service.command.consumer.ConsultarPrestamosEmpleadoPorEstadoCommand;
import com.righttek.ts.solicitarprestamo.service.command.consumer.ConsultarRolPorIdCommand;
import com.righttek.ts.solicitarprestamo.service.command.consumer.ConsultarUsuarioPorEmpleadoIdCommand;
import com.righttek.ts.solicitarprestamo.service.command.consumer.ConsultarValoresEmpresaPorNombreCommand;
import com.righttek.ts.solicitarprestamo.service.command.consumer.CrearSolicitudPrestamoCommand;
import com.righttek.ts.solicitarprestamo.service.command.consumer.CrearSolicitudPrestamoLegadoCommand;
import com.righttek.ts.solicitarprestamo.service.command.consumer.EnviarCorreoCommand;
import com.righttek.ts.solicitarprestamo.service.contract.ISolicitarPrestamoSvc;
import com.righttek.ts.solicitarprestamo.utils.SolicitarPrestamoConvert;

/**
 * @author osarcos
 *
 */
@Service
public class SolicitarPrestamoImpl implements ISolicitarPrestamoSvc{

	private static final Logger LOG = LoggerFactory.getLogger(SolicitarPrestamoImpl.class);
	
	@Autowired
	ConsultarEmpleadoPorIdCommand consultarEmpleadoPorIdCmd;
	
	@Autowired
	ConsultarUsuarioPorEmpleadoIdCommand consultarUsuarioPorEmpleadoIdCmd;
	
	@Autowired
	ConsultarValoresEmpresaPorNombreCommand consultarValoresEmpresaPorNombreCmd;
	
	@Autowired
	ValidarAntiguedadEmpleadoCommand validarAntiguedadEmpleadoCmd;
	
	@Autowired
	ConsultarPrestamosEmpleadoPorEstadoCommand consultarPrestamosEmpleadoPorEstadoCmd;
	
	@Autowired
	ValidarPrestamosAnterioresCommand validarPrestamosAnterioresCmd;
	
	@Autowired
	ConsultarRolPorIdCommand consultarRolPorIdCmd;
	
	@Autowired
	ValidarPrestamoCommand validarPrestamoCmd;
	
	@Autowired
	ConsultarPlantillaNotificacionEmpresaPorNombreCommand consultarPlantillaNotificacionEmpresaPorNombreCmd;
	
	@Autowired
	CrearSolicitudPrestamoCommand crearSolicitudPrestamoCmd;
	
	@Autowired
	CrearSolicitudPrestamoLegadoCommand crearSolicitudPrestamoLegadoCmd;
	
	@Autowired
	VincularParametrosNotificacionCommand vincularParametrosNotificacionCmd;
	
	@Autowired
	EnviarCorreoCommand enviarCorreoCmd;
	
	
	@SuppressWarnings("unchecked")
	@Override
	public Object solicitarPrestamo(SolicitudPrestamoType solicitudPrestamoType) throws BusinessException {

		LOG.info("INICIA SOLICITAR PRESTAMO SERVICE");

		/*
		 * DECLARAMOS VARIABLES QUE REUTILIZAREMOS A LOS LARGO DE LA IMPLEMENTACION
		 */
		GenericStringParam genericStringParams; // permite armar un conjunto de parametros de tipo de dato primitivo para ser enviado a los comandos
		String empresaId = solicitudPrestamoType.getEmpresaId();
		SolicitudPrestamoParam solicitudPrestamoParam = SolicitarPrestamoConvert.modelToType(solicitudPrestamoType) ;
				
		/*
		 * CONSULTA DE EMPLEADO POR ID PARA OBTENER INFORMACION BASICA DEL EMPLEADO
		 */
		EmpleadoLegacyType empleado = (EmpleadoLegacyType) consultarEmpleadoPorIdCmd.execute(solicitudPrestamoParam);
		
		/*
		 * CONSULTA DE USUARIO POR EMPLEADO ID PARA OBTENER ROL DEL USUARIO
		 */
		UsuarioType usuario = (UsuarioType) consultarUsuarioPorEmpleadoIdCmd.execute(solicitudPrestamoParam);
		
		/*
		 * SE CONSULTA VALORES CONFIGURABLES POR MEDIO DE EMPRESAID Y "TIEMPOANTIGUEDADSOLICITUDPRESTAMO" PARA EL 
		 * TIEMPO DE ANTIGUEDAD SEGÚN POLÍTICA DE EMPRESA
		 */
		genericStringParams = new GenericStringParam().addValue("empresaId", empresaId).addValue("nombreParametro", SolicitarPrestamoConstants.TIEMPO_ANTIGUEDAD);
		ParametrosEmpresaType parametroAntiguedad = (ParametrosEmpresaType) consultarValoresEmpresaPorNombreCmd.execute(genericStringParams);
		
		/*
		 * VERIFICA VALIDACIONES SOLICITAR PRESTAMO PARA PERMITIR SEGUIR EL FLUJO
		 */
		ValidarAntiguedadEmpleadoDTO validarAntiguedadEmpleadoParam = new ValidarAntiguedadEmpleadoDTO();
		validarAntiguedadEmpleadoParam.setTiempoAntiguedad(Integer.valueOf(parametroAntiguedad.getValorConfigurableId().getValor()));
		validarAntiguedadEmpleadoParam.setEmpleado(empleado);
		
		validarAntiguedadEmpleadoCmd.execute(validarAntiguedadEmpleadoParam);
		
		/*
		 * SE MANDA A CONSULTAR LOS PRESTAMOS QUE POSEE EL EMPLEADO EN LEGADO POR EMPLEADOID Y POR ESTADO DE SOLICITUD
		 */
		List<PrestamoType> prestamosPendientes = (List<PrestamoType>) consultarPrestamosEmpleadoPorEstadoCmd.execute(solicitudPrestamoParam);
		
		/*
		 * VERIFICA LOS PRESTAMOS ANTERIORES PARA CONTINUAR FLUJO EN CASO DE NO POSEER PENDIENTES
		 */
		ValidarPrestamosAnterioresDTO validarPrestamosAnterioresParam = new ValidarPrestamosAnterioresDTO();
		validarPrestamosAnterioresParam.setListPrestamo(prestamosPendientes);
		
		validarPrestamosAnterioresCmd.execute(validarPrestamosAnterioresParam);
		
		/*
		 * SE CONSULTA VALORES CONFIGURABLES POR MEDIO DE EMPRESAID Y "TIEMPOPAGOSOLICITUDPRESTAMO" PARA EL 
		 * TIEMPO DE PAGO DEL PRESTAMO SEGÚN POLÍTICA DE EMPRESA
		 */
		genericStringParams = new GenericStringParam().addValue("empresaId", empresaId).addValue("nombreParametro", SolicitarPrestamoConstants.TIEMPO_PAGO_PRESTAMO);
		ParametrosEmpresaType parametroTiempoPago = (ParametrosEmpresaType) consultarValoresEmpresaPorNombreCmd.execute(genericStringParams);
		
		/*
		 * SE MANDA A CONSULTAR EL ROL CONFIGURADO POR EMPRESA ID Y ROL ID
		 */
		genericStringParams = new GenericStringParam().addValue("empresaId", empresaId).addValue("rolId", usuario.getRolId());
		RolType rolEmpleado = (RolType) consultarRolPorIdCmd.execute(genericStringParams);
		
		/*
		 * VALIDA PRESTAMO SEGÚN LÓGICA DE NEGOCIOS. VERIFICA EL VALOR DEL PRESTAMO Y EL TIEMPO DE PAGO DEL PRESTAMO
		 */
		ValidarPrestamoDTO validarPrestamoParam = new ValidarPrestamoDTO();
		validarPrestamoParam.setTiempoMaximoPago(Integer.valueOf(parametroTiempoPago.getValorConfigurableId().getValor()));
		validarPrestamoParam.setValorMaximo(rolEmpleado.getCantidadMaximaPrestamo());
		validarPrestamoParam.setSolicitudPrestamo(solicitudPrestamoParam);
		
		validarPrestamoCmd.execute(validarPrestamoParam);
		
		/*
		 * CONSULTA DE PLANTILLA DE NOTIFICACION SEGUN LA EMPRESA Y EL NOMBRE DE LA PLATILLA
		 */
		genericStringParams = new GenericStringParam().addValue("empresaId", empresaId).addValue("nombrePlantilla", SolicitarPrestamoConstants.NOMBRE_PLANTILLA);
		PlantillaNotificacionType plantillaNotificacion = (PlantillaNotificacionType) consultarPlantillaNotificacionEmpresaPorNombreCmd.execute(genericStringParams);
		
		/*
		 * SE CREA LA SOLICITUD DE PRESTAMO LEGADO LLAMANDO AL SERVICIO SolicitudLegadoUS
		 */
		RespuestaType	respuesta = (RespuestaType) crearSolicitudPrestamoLegadoCmd.execute(solicitudPrestamoParam);
		
		/*
		 * SE CREA LA SOLICITUD DE PRESTAMO LLAMANDO AL SERVICIO SolicitudPrestamoES
		 */
		String[]splitIdLegado= respuesta.getDescripcion().split("-");
		solicitudPrestamoParam.setIdSolicitudLegado(Integer.valueOf(splitIdLegado[1]));
		 respuesta = (RespuestaType) crearSolicitudPrestamoCmd.execute(solicitudPrestamoParam);
		 respuesta.setDescripcion(splitIdLegado[0]);
		
		/*
		 * VINCULAR PARAMETROS DE NOTIFICACION
		 */
		
		VincularParametrosNotificacionDTO parametrosNotificacionDTO = new VincularParametrosNotificacionDTO();
		parametrosNotificacionDTO.setPlantillaNotificacionType(plantillaNotificacion);
		parametrosNotificacionDTO.setSolicitudPrestamoType(solicitudPrestamoParam);
		parametrosNotificacionDTO.setNombreEmpleado(empleado.getNombresCompletos());
		
		CorreoParam correoParam = (CorreoParam) vincularParametrosNotificacionCmd.execute(parametrosNotificacionDTO);

		/*
		 * NOTIFICAMOS VIA CORREO ELECTRONICO
		 */	
		enviarCorreoCmd.execute(correoParam);

		LOG.info("FINALIZA SOLICITAR PRESTAMO SERVICE");
		return respuesta;

	}


	@SuppressWarnings("unchecked")
	@Override
	public Boolean validarSolicitudPrestamo(String empleadoId, Double valorPrestamo, Integer cuotasPrestamo)
			throws BusinessException {

		LOG.info("INICIA VALIDAR SOLICITUD PRESTAMO SERVICE");

		/*
		 * DECLARAMOS VARIABLES QUE REUTILIZAREMOS A LOS LARGO DE LA IMPLEMENTACION
		 */
		GenericStringParam genericStringParams; // permite armar un conjunto de parametros de tipo de dato primitivo para ser enviado a los comandos
		
		/*
		 * CONSULTA DE EMPLEADO POR ID PARA OBTENER INFORMACION BASICA DEL EMPLEADO
		 */
		genericStringParams = new GenericStringParam().addValue("empleadoId", empleadoId);
		EmpleadoLegacyType empleado = (EmpleadoLegacyType) consultarEmpleadoPorIdCmd.execute(genericStringParams);
		
		/*
		 * CONSULTA DE USUARIO POR EMPLEADO ID PARA OBTENER ROL DEL USUARIO
		 */
		genericStringParams = new GenericStringParam().addValue("empleadoId", empleadoId);
		UsuarioType usuario = (UsuarioType) consultarUsuarioPorEmpleadoIdCmd.execute(genericStringParams);
		
		/*
		 * SE CONSULTA VALORES CONFIGURABLES POR MEDIO DE EMPRESAID Y "TIEMPOANTIGUEDADSOLICITUDPRESTAMO" PARA EL 
		 * TIEMPO DE ANTIGUEDAD SEGÚN POLÍTICA DE EMPRESA
		 */
		genericStringParams = new GenericStringParam().addValue("empresaId", empleado.getEmpresaId()).addValue("nombreParametro", SolicitarPrestamoConstants.TIEMPO_ANTIGUEDAD);
		ParametrosEmpresaType parametroAntiguedad = (ParametrosEmpresaType) consultarValoresEmpresaPorNombreCmd.execute(genericStringParams);
		
		/*
		 * VERIFICA VALIDACIONES SOLICITAR PRESTAMO PARA PERMITIR SEGUIR EL FLUJO
		 */
		ValidarAntiguedadEmpleadoDTO validarAntiguedadEmpleadoParam = new ValidarAntiguedadEmpleadoDTO();
		validarAntiguedadEmpleadoParam.setTiempoAntiguedad(Integer.valueOf(parametroAntiguedad.getValorConfigurableId().getValor()));
		validarAntiguedadEmpleadoParam.setEmpleado(empleado);
		
		validarAntiguedadEmpleadoCmd.execute(validarAntiguedadEmpleadoParam);
		
		/*
		 * SE MANDA A CONSULTAR LOS PRESTAMOS QUE POSEE EL EMPLEADO EN LEGADO POR EMPLEADOID Y POR ESTADO DE SOLICITUD
		 */
		genericStringParams = new GenericStringParam().addValue("empleadoId", empleadoId).addValue("estadoSolicitud", EstadoSolicitud.PENDIENTE.toString());
		List<PrestamoType> prestamosPendientes = (List<PrestamoType>) consultarPrestamosEmpleadoPorEstadoCmd.execute(genericStringParams);
		
		/*
		 * VERIFICA LOS PRESTAMOS ANTERIORES PARA CONTINUAR FLUJO EN CASO DE NO POSEER PENDIENTES
		 */
		ValidarPrestamosAnterioresDTO validarPrestamosAnterioresParam = new ValidarPrestamosAnterioresDTO();
		validarPrestamosAnterioresParam.setListPrestamo(prestamosPendientes);
		
		validarPrestamosAnterioresCmd.execute(validarPrestamosAnterioresParam);
		
		/*
		 * SE CONSULTA VALORES CONFIGURABLES POR MEDIO DE EMPRESAID Y "TIEMPOPAGOSOLICITUDPRESTAMO" PARA EL 
		 * TIEMPO DE PAGO DEL PRESTAMO SEGÚN POLÍTICA DE EMPRESA
		 */
		genericStringParams = new GenericStringParam().addValue("empresaId", empleado.getEmpresaId()).addValue("nombreParametro", SolicitarPrestamoConstants.TIEMPO_PAGO_PRESTAMO);
		ParametrosEmpresaType parametroTiempoPago = (ParametrosEmpresaType) consultarValoresEmpresaPorNombreCmd.execute(genericStringParams);
		
		/*
		 * SE MANDA A CONSULTAR EL ROL CONFIGURADO POR EMPRESA ID Y ROL ID
		 */
		genericStringParams = new GenericStringParam().addValue("empresaId", empleado.getEmpresaId()).addValue("rolId", usuario.getRolId());
		RolType rolEmpleado = (RolType) consultarRolPorIdCmd.execute(genericStringParams);
		
		/*
		 * VALIDA PRESTAMO SEGÚN LÓGICA DE NEGOCIOS. VERIFICA EL VALOR DEL PRESTAMO Y EL TIEMPO DE PAGO DEL PRESTAMO
		 */
		ValidarPrestamoDTO validarPrestamoParam = new ValidarPrestamoDTO();
		validarPrestamoParam.setTiempoMaximoPago(Integer.valueOf(parametroTiempoPago.getValorConfigurableId().getValor()));
		validarPrestamoParam.setValorMaximo(rolEmpleado.getCantidadMaximaPrestamo());
		validarPrestamoParam.setSolicitudPrestamo(solicitudPrestamoParam);
		
		validarPrestamoCmd.execute(validarPrestamoParam);

		LOG.info("FINALIZA VALIDAR SOLICITUD PRESTAMO SERVICE");
		return respuesta;

	}


	@Override
	public Boolean registrarSolicitudPrestamo(SolicitudPrestamoType solicitudPrestamoType) throws BusinessException {
		// TODO Auto-generated method stub
		return null;
	}

}
