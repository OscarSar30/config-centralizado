package com.righttek.ts.solicitarprestamo.constants;
 /**
  * 
  * @author osarcos
  *
  */
public class SolicitarPrestamoConstants {

	private SolicitarPrestamoConstants() {
		
	}
	
	// URI DE SERVICIOS A UTILIZAR
	public final static String CONSULTAR_EMPLEADO_POR_ID = "/api/es/empleado/v1/{empleadoId}";
	public final static String CONSULTAR_USUARIO_POR_EMPLEADO_ID = "api/es/usuario/empleado/id/v1/{empleadoId}";
	public final static String CONSULTAR_VALORES_EMPRESA_POR_NOMBRE = "/api/es/valoresConfigurables/empresa/nombre/v1/{empresaId}/{nombre}";
	public final static String CONSULTAR_PRESTAMOS_EMPLEADO_ESTADO = "/api/us/nominaexterna/prestamo/empleado/estado/v1/{empleadoId}/{estadoSolicitud}";
	public final static String CONSULTAR_ROL_POR_ID = "/api/es/rol/empresa/id/v1/{empresaId}/{rolId}";
	public final static String CONSULTAR_PLANTILLA_NOTIFICACION_EMPRESA_POR_NOMBRE = "/api/es/plantillaNotificacion/empresa/v1/{empresaId}/{nombrePlantilla}";
	public final static String CREAR_SOLICITUD_PRESTAMO = "/api/es/solicitud/prestamo/v1";
	public final static String CREAR_SOLICITUD_PRESTAMO_LEGADO = "/api/us/solicitudLegado/prestamo/solicitud/v1";
	public static final String ENVIAR_CORREO = "/api/us/enviarCorreo/v1";
	
	// PARAMETROS DE EMPRESA
	public static final String TIEMPO_ANTIGUEDAD = "TIEMPOANTIGUEDADSOLICITUDPRESTAMO";
	public static final String TIEMPO_PAGO_PRESTAMO = "TIEMPOPAGOSOLICITUDPRESTAMO";
	public static final String NOMBRE_PLANTILLA = "REGISTROSOLICITUDPRESTAMO";
	
	// MENSAJES DE RESPUESTA
	public static final String MENSAJE_ERROR_CONSULTA= "A OCURRIDO UN ERROR AL CONSULTAR INFORMACIÓN DE %s";
	public static final String MENSAJE_ERROR_CREAR= "A OCURRIDO UN ERROR AL CREAR %s";
	public static final String POSEE_PRESTAMOS_PENDIENTES = "Usuario posee prestamos pendientes por aprobar";
	public static final String ANTIGUEDAD = "Usuario no tiene el tiempo mínimo requerido en la empresa para solicitar un prestamo";
	public static final String TIEMPO_PAGO_EXCEDIDO = "El tiempo de pago del prestamo en la solicitud es mayor al tiempo parametrizado";
	public static final String VALOR_PRESTAMO_EXCEDIDO = "El valor del prestamo en la solicitud es mayor al valor parametrizado";
	
}
