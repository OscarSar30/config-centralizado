package com.righttek.ts.solicitarprestamo.controller.dto;

import com.righttek.gotalent.comun.patrones.command.IParam;
import com.righttek.gotalent.modelo_canonico.SolicitudPrestamoType;

/**
 * 
 * @author osarcos
 *
 */
public class ValidarPrestamoDTO implements IParam{
	
	private SolicitudPrestamoType solicitudPrestamo;
	private Integer tiempoMaximoPago;
	private Double valorMaximo;
	
	/**
	 * @return the solicitudPrestamo
	 */
	public SolicitudPrestamoType getSolicitudPrestamo() {
		return solicitudPrestamo;
	}
	/**
	 * @param solicitudPrestamo the solicitudPrestamo to set
	 */
	public void setSolicitudPrestamo(SolicitudPrestamoType solicitudPrestamo) {
		this.solicitudPrestamo = solicitudPrestamo;
	}
	/**
	 * @return the tiempoMaximoPago
	 */
	public Integer getTiempoMaximoPago() {
		return tiempoMaximoPago;
	}
	/**
	 * @param tiempoMaximoPago the tiempoMaximoPago to set
	 */
	public void setTiempoMaximoPago(Integer tiempoMaximoPago) {
		this.tiempoMaximoPago = tiempoMaximoPago;
	}
	/**
	 * @return the valorMaximo
	 */
	public Double getValorMaximo() {
		return valorMaximo;
	}
	/**
	 * @param valorMaximo the valorMaximo to set
	 */
	public void setValorMaximo(Double valorMaximo) {
		this.valorMaximo = valorMaximo;
	}

}
