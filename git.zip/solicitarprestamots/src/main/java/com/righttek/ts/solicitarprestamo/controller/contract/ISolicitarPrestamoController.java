/**
 * 
 */
package com.righttek.ts.solicitarprestamo.controller.contract;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.righttek.gotalent.comun.utilitarios.RespuestaType;
import com.righttek.gotalent.modelo_canonico.SolicitudPrestamoType;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * @author osarcos
 *
 */
@Validated
@Tag(name = "SolicitarPrestamoTSV1", description = "Servicio de Tarea de Solicitar Prestamo")
public interface ISolicitarPrestamoController {
	
	/**
     * GET /prestamo/v1/{empleadoId}/{valorPrestamo}/{cuotasPrestamo} : Validar Solicitud Prestamo
     * Capacidad que permite realizar las validaciones de un solicitud de prestamo antes de registrar
     *
     * @param empleadoId  (required)
     * @param valorPrestamo  (required)
     * @param cuotasPrestamo  (required)
     * @return OK (status code 200)
     *         or Bad Request (status code 400)
     *         or Not Found (status code 404)
     *         or Internal Server Error (status code 500)
     */
	@Operation(operationId = "Validar Solicitud Préstamo", method = "validarSolicitudPrestamo", description = "Capacidad que permite realizar las validaciones de un solicitud de préstamo antes de registrar", tags={ "SolicitarPrestamoTSV1", }, summary = "Capacidad que permite realizar las validaciones de un solicitud de préstamo antes de registrar")
	@ApiResponses(value = { 
    	@ApiResponse(responseCode = "200", description = "OK",content = @Content(schema = @Schema(implementation = Boolean.class))),
    	@ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(schema = @Schema(implementation = RespuestaType.class))),
        @ApiResponse(responseCode = "404", description = "Not Found", content = @Content(schema = @Schema(implementation = RespuestaType.class))),
        @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(schema = @Schema(implementation = RespuestaType.class))) })
 
    @GetMapping(value = "/prestamo/v1/{empleadoId}/{valorPrestamo}/{cuotasPrestamo}",
        produces = "application/json; charset=UTF-8")
	ResponseEntity<?> validarSolicitudPrestamo(@PathVariable (name = "empleadoId", required = true) String empleadoId,
											   @PathVariable (name = "valorPrestamo", required = true) Double valorPrestamo,
											   @PathVariable (name = "cuotasPrestamo", required = true) Integer cuotasPrestamo);
	
	
	/**
     * POST /prestamo/v1 : Registrar Solicitud Prestamo
     * Capacidad encargada de registrar una solicitud de prestamo en la plataforma
     *
     * @param solicitudPrestamoType  (required)
     * @return OK (status code 200)
     *         or Bad Request (status code 400)
     *         or Internal Server Error (status code 500)
     */
	@Operation(operationId = "Registrar Solicitud Prestamo", method = "registrarSolicitudPrestamo", description = "Capacidad encargada de registrar una solicitud de préstamo en la plataforma",tags={ "SolicitarPrestamoTSV1", }, summary = "Capacidad encargada de registrar una solicitud de préstamo en la plataforma")
	@ApiResponses(value = { 
    	@ApiResponse(responseCode = "200", description = "OK",content = @Content(schema = @Schema(implementation = RespuestaType.class))),
        @ApiResponse(responseCode = "400", description = "Bad Request",content = @Content(schema = @Schema(implementation = RespuestaType.class))),
        @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(schema = @Schema(implementation = RespuestaType.class))) })
 
    @RequestMapping(value = "/prestamo/v1",
        produces = "application/json; charset=UTF-8", 
        method = RequestMethod.POST)
	ResponseEntity<?> registrarSolicitudPrestamo(@Valid @RequestBody(required = true) SolicitudPrestamoType solicitudPrestamoType);
	
	/**
	 * POST /prestamo/v1 : SolicitarPrestamo
     * Solicitar un prestamo
     * 
	 * @param solicitudPrestamoType
	 * @return OK (status code 200)
     *         or Bad Request (status code 400)
     *         or Internal Server Error (status code 500)
	 */
	@Operation(operationId = "solicitarPrestamo", method = "solicitarPrestamo", description = "Solicitar un prestamo", tags = {"SolicitarPrestamoTSV1",})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "OK", content = @Content(schema = @Schema(implementation = RespuestaType.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(schema = @Schema(implementation = RespuestaType.class))),
			@ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(schema = @Schema(implementation = RespuestaType.class)))
	})
	@RequestMapping(value = "/prestamo/v1", produces = "application/json", method = RequestMethod.POST)
	ResponseEntity<?> solicitarPrestamo (@Valid @RequestBody(required = true) SolicitudPrestamoType solicitudPrestamoType);

}
