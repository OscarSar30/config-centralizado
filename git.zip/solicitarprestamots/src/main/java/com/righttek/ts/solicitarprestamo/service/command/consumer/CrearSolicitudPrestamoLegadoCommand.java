/**
 * 
 */
package com.righttek.ts.solicitarprestamo.service.command.consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.righttek.gotalent.comun.exception.BusinessException;
import com.righttek.gotalent.comun.exception.TipoError;
import com.righttek.gotalent.comun.patrones.command.ICommand;
import com.righttek.gotalent.comun.patrones.command.IParam;
import com.righttek.gotalent.comun.utilitarios.RespuestaType;
import com.righttek.ts.solicitarprestamo.constants.SolicitarPrestamoConstants;
import com.righttek.ts.solicitarprestamo.controller.dto.SolicitudPrestamoParam;

/**
 * 
 * COMANDO UTILIZADO PARA CREAR UNA SOLICITUD DE PRESTAMO EN LEGADO UNA VEZ TERMINADO DE REALIZAR SUS RESPECTIVAS
 * VALIDACIONES DE NEGOCIO
 *
 */
@Component
public class CrearSolicitudPrestamoLegadoCommand implements ICommand{

	private static final Logger LOG = LoggerFactory.getLogger(CrearSolicitudPrestamoLegadoCommand.class);

	@Value("${uri.solicitudLegado}")
	private String hostService;
	
	@Override
	public Object execute(IParam parametro) throws BusinessException {
		
		LOG.info("INICIA COMMAND CREAR SOLICITUD PRESTAMO LEGADO");

		SolicitudPrestamoParam solicitud = (SolicitudPrestamoParam) parametro;

		/* 
		 * DECLARAMOS LO OBJETOS QUE USAREMOS PARA DEFINIR EL REQUEST 
		 * Y REALIZAR EL LLAMADO A AL ENDPOINT DE LA API CORRESPONDIENTE
		 */
		HttpHeaders headers = new HttpHeaders();
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<RespuestaType> response;
		
		try {
			/* REALIZAMOS EL LLAMADO A LA CAPACIDAD "crearSolicitudPrestamo" DEL SERVICIO "SolicitudLegadoUS" */
			headers.set("Content-Type", "application/json");
			HttpEntity<SolicitudPrestamoParam> request = new HttpEntity<SolicitudPrestamoParam>(solicitud, headers);
			
			response = restTemplate.exchange(
					hostService.concat(SolicitarPrestamoConstants.CREAR_SOLICITUD_PRESTAMO_LEGADO), HttpMethod.POST, request,
					RespuestaType.class);
			LOG.info("FINALIZA COMMAND CREAR SOLICITUD PRESTAMO LEGADO");
			
		} catch (HttpStatusCodeException e) {
			LOG.error("ERROR EN COMMAND CREAR SOLICITUD PRESTAMO LEGADO: {}",e.fillInStackTrace());
			throw new BusinessException(String.format(SolicitarPrestamoConstants.MENSAJE_ERROR_CREAR,"LA SOLICITUD DE PRESTAMO LEGADO"),TipoError.FUENTE_DE_DATOS, e.getCause());
		}

		return response.getBody();
		
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		
	}

}
