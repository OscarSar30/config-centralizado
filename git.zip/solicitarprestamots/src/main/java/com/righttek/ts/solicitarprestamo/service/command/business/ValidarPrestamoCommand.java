/**
 * 
 */
package com.righttek.ts.solicitarprestamo.service.command.business;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.righttek.gotalent.comun.exception.BusinessException;
import com.righttek.gotalent.comun.exception.TipoError;
import com.righttek.gotalent.comun.patrones.command.ICommand;
import com.righttek.gotalent.comun.patrones.command.IParam;
import com.righttek.ts.solicitarprestamo.constants.SolicitarPrestamoConstants;
import com.righttek.ts.solicitarprestamo.controller.dto.ValidarPrestamoDTO;
import com.righttek.ts.solicitarprestamo.utils.SolicitarPrestamoValidator;

/**
 * @author osarcos
 * 
 * COMANDO QUE USAREMOS PARA VALIDAR PRESTAMO DEL EMPLEADO SEGÚN PARAMETROS CONFIGURADOS PARA LA EMPRESA Y EL VALOR
 * REQUERIDO PARA REALIZAR LA PETICION
 *
 */
@Component
public class ValidarPrestamoCommand implements ICommand{

	private static final Logger LOG = LoggerFactory.getLogger(ValidarPrestamoCommand.class);
	
	@Override
	public Object execute(IParam parametro) throws BusinessException {
		
		LOG.info("INICIA COMMAND VALIDAR PRESTAMO");
		
		ValidarPrestamoDTO validarPrestamoParam = (ValidarPrestamoDTO) parametro;
		
		/* 
		 * OBTENEMOS EL TIEMPO DE FECHA FIN DEL COBRO EN MESES 
		 */
		int finCobroMeses = SolicitarPrestamoValidator.obtenerTiempoEnMeses(validarPrestamoParam.getSolicitudPrestamo().getPrestamo().getFechaFin(), validarPrestamoParam.getSolicitudPrestamo().getPrestamo().getFechaInicio());
		
		/* 
		 * VALIDAMOS SI EL TIEMPO DE PAGO DEL PRESTAMO ES MAYOR A LA VALOR PARAMETRIZADO
		 */
		if (finCobroMeses > validarPrestamoParam.getTiempoMaximoPago()) {
			LOG.info("FINALIZA COMMAND VALIDAR PRESTAMO POR BUSINESSEXCEPTION");
			throw new BusinessException(SolicitarPrestamoConstants.TIEMPO_PAGO_EXCEDIDO,TipoError.LOGICA_NEGOCIO);
		}
		
		/* 
		 * VALIDAMOS SI EL TIEMPO DE PAGO DEL PRESTAMO ES MAYOR A LA VALOR PARAMETRIZADO
		 */
		if (validarPrestamoParam.getSolicitudPrestamo().getPrestamo().getValorTotal() > validarPrestamoParam.getValorMaximo()) {
			LOG.info("FINALIZA COMMAND VALIDAR PRESTAMO POR BUSINESSEXCEPTION");
			throw new BusinessException(SolicitarPrestamoConstants.VALOR_PRESTAMO_EXCEDIDO,TipoError.LOGICA_NEGOCIO);
		}

		/* 
		 * CALCULAR DESGLOSE DE PAGOS POR PRÉSTAMO
		 */
		validarPrestamoParam.getSolicitudPrestamo().getPrestamo().getDesglosePago().values();
		int sum = validarPrestamoParam.getSolicitudPrestamo().getPrestamo().getDesglosePago().values().stream().mapToInt(Number::intValue).sum();
		
		if (sum != 0) {
			return sum;
		}
		
		LOG.info("FINALIZA COMMAND VALIDAR PRESTAMO");
		return null;
		
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		
	}

}
