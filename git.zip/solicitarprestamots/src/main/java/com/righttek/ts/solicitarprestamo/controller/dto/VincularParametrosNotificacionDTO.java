package com.righttek.ts.solicitarprestamo.controller.dto;

import com.righttek.gotalent.comun.patrones.command.IParam;
import com.righttek.gotalent.modelo_canonico.PlantillaNotificacionType;
import com.righttek.gotalent.modelo_canonico.SolicitudPrestamoType;

public class VincularParametrosNotificacionDTO implements IParam {

	private PlantillaNotificacionType plantillaNotificacionType;
	private String nombreEmpleado;
	private SolicitudPrestamoType solicitudPrestamoType;
	
	/**
	 * @return the plantillaNotificacionType
	 */
	public PlantillaNotificacionType getPlantillaNotificacionType() {
		return plantillaNotificacionType;
	}
	/**
	 * @param plantillaNotificacionType the plantillaNotificacionType to set
	 */
	public void setPlantillaNotificacionType(PlantillaNotificacionType plantillaNotificacionType) {
		this.plantillaNotificacionType = plantillaNotificacionType;
	}
	/**
	 * @return the nombreEmpleado
	 */
	public String getNombreEmpleado() {
		return nombreEmpleado;
	}
	/**
	 * @param nombreEmpleado the nombreEmpleado to set
	 */
	public void setNombreEmpleado(String nombreEmpleado) {
		this.nombreEmpleado = nombreEmpleado;
	}
	/**
	 * @return the solicitudPrestamoType
	 */
	public SolicitudPrestamoType getSolicitudPrestamoType() {
		return solicitudPrestamoType;
	}
	/**
	 * @param solicitudPrestamoType the solicitudPrestamoType to set
	 */
	public void setSolicitudPrestamoType(SolicitudPrestamoType solicitudPrestamoType) {
		this.solicitudPrestamoType = solicitudPrestamoType;
	}
	
}
