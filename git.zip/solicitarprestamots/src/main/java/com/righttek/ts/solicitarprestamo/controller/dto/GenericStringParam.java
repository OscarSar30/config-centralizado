package com.righttek.ts.solicitarprestamo.controller.dto;

import java.util.HashMap;
import java.util.Map;

import com.righttek.gotalent.comun.patrones.command.IParam;

/**
 * 
 * @author fobregon
 *
 * Clase que permite encampsular "N" numero de parametros en String que necesiten ser enviados 
 * ya sea a comandos de consumo o de negocio
 */
public class GenericStringParam  implements IParam{
	
	private Map<String, String> values = new HashMap<>();

	public Map<String, String> getValues() {
		return values;
	}
	
	public void setValues(Map<String, String> values) {
		this.values = values;
	}
	
	public GenericStringParam addValue(String key, String value){
		this.values.put(key, value);
		return this;
	}


}