package com.righttek.ts.solicitarprestamo.service.command.consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.righttek.gotalent.comun.exception.BusinessException;
import com.righttek.gotalent.comun.exception.TipoError;
import com.righttek.gotalent.comun.patrones.command.ICommand;
import com.righttek.gotalent.comun.patrones.command.IParam;
import com.righttek.gotalent.comun.utilitarios.RespuestaType;
import com.righttek.ts.solicitarprestamo.constants.SolicitarPrestamoConstants;
import com.righttek.ts.solicitarprestamo.controller.dto.CorreoParam;

/**
 * @author osarcos
 * 
 * COMANDO QUE USAREMOS PARA ENVIO DE CORREO AL MOMENTO DE NOTIFICAR A LOS USUARIOS IMPLICADOS
 * EN EL PROCESO DE UNA SOLICITUD DE CAMBIO HORARIO
 *
 */
@Component
public class EnviarCorreoCommand implements ICommand{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(EnviarCorreoCommand.class);

	@Value("${uri.enviarCorreo}")
	private String hostService;

	@Override
	public Object execute(IParam parametro) throws BusinessException {
		
		LOGGER.info("INICIA COMANDO ENVIAR CORREO");
		/* DECLARACION DE VARIABLES A UTILIZAR*/
		CorreoParam correo = (CorreoParam) parametro;
		
		/* 
		 * DECLARAMOS LO OBJETOS QUE USAREMOS PARA DEFINIR EL REQUEST 
		 * Y REALIZAR EL LLAMADO A AL ENDPOINT DE LA API CORRESPONDIENTE
		 */
		HttpHeaders headers = new HttpHeaders();
		RestTemplate restTemplate = new RestTemplate();
		headers.set("Content-Type", "application/json; charset=UTF-8");
		HttpEntity<CorreoParam> request = new HttpEntity<CorreoParam>(correo, headers);
		ResponseEntity<RespuestaType> response;
		
		/* REALIZAMOS EL LLAMADO A LA CAPACIDAD "enviarCorreo" DEL SERVICIO "EnviarCorreoUS" */
		try {
			response = restTemplate.exchange(
					hostService.concat(SolicitarPrestamoConstants.ENVIAR_CORREO), 
					HttpMethod.POST, request, RespuestaType.class);
			
		}catch (HttpStatusCodeException e) {
			LOGGER.error("ERROR EN COMANDO ENVIAR CORREO {}",e.getMessage());
			throw new BusinessException("A OCURRIDO UN ERROR EN EL ENVIO DE CORREO", TipoError.FUENTE_DE_DATOS,e.getCause());
		}
		LOGGER.info("FINALIZA COMANDO ACTUALIZAR ENVIAR CORREO");
		return response.getBody();
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		
	}

}
