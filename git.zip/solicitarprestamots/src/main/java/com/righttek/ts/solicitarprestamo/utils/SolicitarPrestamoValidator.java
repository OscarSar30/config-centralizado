package com.righttek.ts.solicitarprestamo.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.righttek.gotalent.modelo_canonico.EmpleadoLegacyType;

public class SolicitarPrestamoValidator {

	public SolicitarPrestamoValidator() {
		
	}

	public static int obtenerTiempoEnMeses(EmpleadoLegacyType empleadoLegacy, Date fechaActual) {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar inicio = Calendar.getInstance();
		Calendar fin = Calendar.getInstance();
		String strFechaIngreso = sdf.format(empleadoLegacy.getFechaIngreso());
		try {
			inicio.setTime(new SimpleDateFormat("yyyy-MM-dd").parse(strFechaIngreso));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		fin.setTime(fechaActual);
		inicio.add(Calendar.MONTH, 1);
		fin.add(Calendar.MONTH, 1);
		int diferenciaAnio = fin.get(Calendar.YEAR) - inicio.get(Calendar.YEAR);
		int diferenciaMeses = diferenciaAnio * 12 + (fin.get(Calendar.MONTH) - inicio.get(Calendar.MONTH));

		return diferenciaMeses;

	}
	
	public static int obtenerTiempoEnMeses(Date fechaFinCobro, Date fechaActual) {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar inicio = Calendar.getInstance();
		Calendar fin = Calendar.getInstance();
		String strFechaActual = sdf.format(fechaActual);
		try {
			inicio.setTime(new SimpleDateFormat("yyyy-MM-dd").parse(strFechaActual));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		fin.setTime(fechaFinCobro);
		inicio.add(Calendar.MONTH, 1);
		fin.add(Calendar.MONTH, 1);
		int diferenciaAnio = fin.get(Calendar.YEAR) - inicio.get(Calendar.YEAR);
		int diferenciaMeses = diferenciaAnio * 12 + (fin.get(Calendar.MONTH) - inicio.get(Calendar.MONTH));

		return diferenciaMeses;

	}
	
}
