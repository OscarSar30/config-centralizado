package com.righttek.ts.solicitarprestamo.utils;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.models.ExternalDocumentation;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;

/**
 * 
 * @author osarcos
 *
 */

@Configuration
@OpenAPIDefinition
public class OpenApiConfig {
	
	@Bean
	public OpenAPI customOpenApi() {
		return new OpenAPI().info(new Info()
				.title("SolicitarPrestamoTS")
				.description("Servicio de Tarea para Solicitar un Prestamo")
				.version("1.0.0")
				.contact(new Contact().name("Righttek S.A.").email("api@righttek.com").url("http://www.righttek.com"))
				.license(new License().name("Apache 2.0").url("http://www.gnu.org/licenses/gpi-3.0.html")))
				.externalDocs(new ExternalDocumentation().description("API RESTful SolicitarPrestamoTS").url(""));
	}

}
