package com.righttek.ts.solicitarprestamo.utils;

import org.modelmapper.ModelMapper;

import com.righttek.gotalent.modelo_canonico.SolicitudPrestamoType;
import com.righttek.ts.solicitarprestamo.controller.dto.SolicitudPrestamoParam;

public class SolicitarPrestamoConvert {

	public SolicitarPrestamoConvert() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static final SolicitudPrestamoParam modelToType(SolicitudPrestamoType solicitudPrestamoType) {
		return new ModelMapper().map(solicitudPrestamoType, SolicitudPrestamoParam.class);
	}
}
