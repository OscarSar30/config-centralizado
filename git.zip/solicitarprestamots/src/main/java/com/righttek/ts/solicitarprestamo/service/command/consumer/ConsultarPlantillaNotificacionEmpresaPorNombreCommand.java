package com.righttek.ts.solicitarprestamo.service.command.consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.righttek.gotalent.comun.exception.BusinessException;
import com.righttek.gotalent.comun.exception.TipoError;
import com.righttek.gotalent.comun.patrones.command.ICommand;
import com.righttek.gotalent.comun.patrones.command.IParam;
import com.righttek.gotalent.modelo_canonico.PlantillaNotificacionType;
import com.righttek.ts.solicitarprestamo.constants.SolicitarPrestamoConstants;
import com.righttek.ts.solicitarprestamo.controller.dto.GenericStringParam;

/**
 * @author osarcos
 * 
 * COMANDO UTILIZADO PARA CONSULTAR PLANTILLA NOTIFICACION QUE TIENE UNA EMPRESA PARA VERIFICAR
 * PLANTILLA HTML UTILIZADA AL MOMENTO DE ENVIAR UN CORREO
 *
 */
@Component
public class ConsultarPlantillaNotificacionEmpresaPorNombreCommand implements ICommand{

	
	private static final Logger LOG = LoggerFactory.getLogger(ConsultarPlantillaNotificacionEmpresaPorNombreCommand.class);
	
	@Value("${uri.plantillaNotificacion}")
	private String hostService;

	
	@Override
	public Object execute(IParam parametro) throws BusinessException {
		
		LOG.info("INICIA COMMAND CONSULTAR PLANTILLA NOTIFICACION EMPRESA POR NOMBRE");
		
		GenericStringParam genericParam = (GenericStringParam) parametro;
		
		/* 
		 * DECLARAMOS LO OBJETOS QUE USAREMOS PARA DEFINIR EL REQUEST 
		 * Y REALIZAR EL LLAMADO A AL ENDPOINT DE LA API CORRESPONDIENTE
		 */
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<PlantillaNotificacionType> response;
		
		try {
			/* REALIZAMOS EL LLAMADO A LA CAPACIDAD "consultarPlantillaNotificacionEmpresaPorNombre" DEL SERVICIO "PlantillaNotificacionES" */
			response = restTemplate.exchange(
					hostService.concat(SolicitarPrestamoConstants.CONSULTAR_PLANTILLA_NOTIFICACION_EMPRESA_POR_NOMBRE),
					HttpMethod.GET, null, 
					new ParameterizedTypeReference<PlantillaNotificacionType>() {},genericParam.getValues().get("empresaId"), genericParam.getValues().get("nombrePlantilla"));
		} catch (HttpStatusCodeException e) {
			LOG.error("HTTP EXCEPCION COMMAND CONSULTAR PLANTILLA NOTIFICACION EMPRESA POR NOMBRE: {}", e.getMessage(), e.getStackTrace());
			throw new BusinessException(String.format(SolicitarPrestamoConstants.MENSAJE_ERROR_CONSULTA,"PLANTILLA DE NOTIFICACION"),TipoError.FUENTE_DE_DATOS);
		}
		
		LOG.info("FINALIZA COMMAND CONSULTAR PLANTILLA NOTIFICACION EMPRESA POR NOMBRE");
		return response.getBody();
		
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		
	}

}
