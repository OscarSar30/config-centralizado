/**
 * 
 */
package com.righttek.ts.solicitarprestamo.service.command.consumer;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.righttek.gotalent.comun.exception.BusinessException;
import com.righttek.gotalent.comun.exception.TipoError;
import com.righttek.gotalent.comun.patrones.command.ICommand;
import com.righttek.gotalent.comun.patrones.command.IParam;
import com.righttek.gotalent.modelo_canonico.PrestamoType;
import com.righttek.ts.solicitarprestamo.constants.SolicitarPrestamoConstants;
import com.righttek.ts.solicitarprestamo.controller.dto.SolicitudPrestamoParam;

/**
 * @author osarcos
 * 
 * COMANDO UTILIZADO PARA CONSULTAR PRESTAMOS DE EMPLEADO POR MEDIO DEL ID A LEGADO PARA CONTINUAR CON
 * EL FLUJO DE SOLICITUD DE PRESTAMO
 *
 */
@Component
public class ConsultarPrestamosEmpleadoPorEstadoCommand implements ICommand{

	private static final Logger LOG = LoggerFactory.getLogger(ConsultarEmpleadoPorIdCommand.class);
	
	@Value("${uri.nominaExterna}")
	private String hostService;
	
	@Override
	public Object execute(IParam parametro) throws BusinessException {

		LOG.info("INICIA COMMAND CONSULTAR EMPLEADO PRESTAMOS POR ID");
		
		SolicitudPrestamoParam solicitudPrestamo = (SolicitudPrestamoParam) parametro;
		
		/* 
		 * DECLARAMOS LO OBJETOS QUE USAREMOS PARA DEFINIR EL REQUEST 
		 * Y REALIZAR EL LLAMADO A AL ENDPOINT DE LA API CORRESPONDIENTE
		 */
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<List<PrestamoType>> response;
		
		try {
			/* REALIZAMOS EL LLAMADO A LA CAPACIDAD "consultarPrestamosEmpleadoPorEstado" DEL SERVICIO "NominaExternaUS" */
			response = restTemplate.exchange(
					hostService.concat(SolicitarPrestamoConstants.CONSULTAR_PRESTAMOS_EMPLEADO_ESTADO),
					HttpMethod.GET, null, 
					new ParameterizedTypeReference<List<PrestamoType>>() {},solicitudPrestamo.getEmpleadoId(), solicitudPrestamo.getEstado());
		} catch (HttpStatusCodeException e) {
			LOG.error("HTTP EXCEPCION COMMAND CONSULTAR EMPLEADO POR ID: {}", e.getMessage(), e.getStackTrace());
			throw new BusinessException(String.format(SolicitarPrestamoConstants.MENSAJE_ERROR_CONSULTA,"PRESTAMO DE EMPLEADO EN LEGADO"),TipoError.FUENTE_DE_DATOS);
		}
		
		LOG.info("FINALIZA COMMAND CONSULTAR EMPLEADO PRESTAMOS  POR ID");
		return response.getBody();
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		
	}

}
