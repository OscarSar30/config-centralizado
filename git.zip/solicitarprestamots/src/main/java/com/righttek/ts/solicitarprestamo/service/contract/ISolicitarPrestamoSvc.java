package com.righttek.ts.solicitarprestamo.service.contract;

import com.righttek.gotalent.comun.exception.BusinessException;
import com.righttek.gotalent.modelo_canonico.SolicitudPrestamoType;

/**
 * 
 * @author osarcos
 *
 */
public interface ISolicitarPrestamoSvc {

	Object solicitarPrestamo (SolicitudPrestamoType solicitudPrestamoType) throws BusinessException;
	public Boolean validarSolicitudPrestamo (String empleadoId, Double valorPrestamo, Integer cuotasPrestamo) throws BusinessException;
	public Boolean registrarSolicitudPrestamo (SolicitudPrestamoType solicitudPrestamoType) throws BusinessException;
	
}
