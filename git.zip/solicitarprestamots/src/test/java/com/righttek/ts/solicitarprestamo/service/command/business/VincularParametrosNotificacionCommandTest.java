package com.righttek.ts.solicitarprestamo.service.command.business;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.righttek.gotalent.comun.exception.BusinessException;
import com.righttek.ts.solicitarprestamo.controller.dto.CorreoParam;
import com.righttek.ts.solicitarprestamo.controller.dto.VincularParametrosNotificacionDTO;

/**
 * @author A.Macias
 *
 */
class VincularParametrosNotificacionCommandTest {
	
	private ObjectMapper objectMapper;
	private File datosJson;
	private VincularParametrosNotificacionCommand vincularParametrosNotificacionCmd;

	/**
	 * @throws Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
		this.objectMapper = new ObjectMapper();
		this.datosJson = new File("src/test/resources/VincularParametrosNotificacion.json");
		this.vincularParametrosNotificacionCmd = new VincularParametrosNotificacionCommand();
	}

	/**
	 * @throws Exception
	 */
	@AfterEach
	void tearDown() throws Exception {
		this.objectMapper = null;
		this.datosJson = null;
		this.vincularParametrosNotificacionCmd = null;
	}
		/**
	 * Test method for {@link com.righttek.ts.solicitarprestamo.service.command.business.VincularParametrosNotificacionCommand#execute(com.righttek.gotalent.comun.patrones.command.IParam)}.
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 * @throws BusinessException 
	 */


	@Test
	void testExecuteVinculandoParametros() throws JsonParseException, JsonMappingException, IOException, BusinessException {
		VincularParametrosNotificacionDTO parametrosNotificacionDTO = objectMapper.readValue(datosJson, new TypeReference<List<VincularParametrosNotificacionDTO>>() {}).get(0);
		
		CorreoParam correoParam = (CorreoParam) vincularParametrosNotificacionCmd.execute(parametrosNotificacionDTO);
		String mensaje = "Nombre: osarcos, Estado: PENDIENTE";
		
		assertEquals(parametrosNotificacionDTO.getPlantillaNotificacionType().getDetalle(), correoParam.getAsunto());
		assertEquals(parametrosNotificacionDTO.getSolicitudPrestamoType().getUsuarioCreacion(), correoParam.getPara());
		assertEquals(mensaje, correoParam.getMensaje());
		
	}

}
