/**
 * 
 */
package com.righttek.ts.solicitarprestamo.service.command.business;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.righttek.gotalent.comun.exception.BusinessException;
import com.righttek.ts.solicitarprestamo.controller.dto.ValidarAntiguedadEmpleadoDTO;

class ValidarAntiguedadEmpleadoCommandTest {
	
	private ObjectMapper objectMapper;
	private File datosJson;
	private ValidarAntiguedadEmpleadoCommand validarAntiguedadEmpleadoCmd;

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
		
		this.objectMapper = new ObjectMapper();
		this.datosJson = new File("src/test/resources/ValidarAntiguedadEmpleado.json");
		this.validarAntiguedadEmpleadoCmd = new ValidarAntiguedadEmpleadoCommand();
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterEach
	void tearDown() throws Exception {
		this.objectMapper = null;
		this.datosJson = null;
		this.validarAntiguedadEmpleadoCmd = null;
	}
	
	/**
	 * Test method for {@link com.righttek.ts.solicitarprestamo.service.command.business.ValidarAntiguedadEmpleadoCommand#execute(com.righttek.gotalent.comun.patrones.command.IParam)}.
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 * @throws BusinessException 
	 */
	@Test
	void testExecuteValidarAntiguedadEmpleadoNoCumpleTiempo() throws JsonParseException, JsonMappingException, IOException, BusinessException {
		ValidarAntiguedadEmpleadoDTO validarAntiguedadEmpleadoDTO = objectMapper.readValue(datosJson, new TypeReference<List<ValidarAntiguedadEmpleadoDTO>>() {}).get(0);
		assertThrows(BusinessException.class, () -> {
			validarAntiguedadEmpleadoCmd.execute(validarAntiguedadEmpleadoDTO);
		  });
	}
	
	/**
	 * Test method for {@link com.righttek.ts.solicitarprestamo.service.command.business.ValidarAntiguedadEmpleadoCommand#execute(com.righttek.gotalent.comun.patrones.command.IParam)}.
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 */
	@Test
	void testExecuteExecuteValidarAntiguedadEmpleadoOK() throws JsonParseException, JsonMappingException, IOException, BusinessException {
		ValidarAntiguedadEmpleadoDTO validarAntiguedadEmpleadoDTO = objectMapper.readValue(datosJson, new TypeReference<List<ValidarAntiguedadEmpleadoDTO>>(){}).get(1);	
		assertNull(validarAntiguedadEmpleadoCmd.execute(validarAntiguedadEmpleadoDTO));
	}

}
