/**
 * 
 */
package com.righttek.ts.solicitarprestamo.service.command.business;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.righttek.gotalent.comun.exception.BusinessException;
import com.righttek.ts.solicitarprestamo.controller.dto.ValidarPrestamosAnterioresDTO;

class ValidarPrestamosAnterioresCommandTest {
	
	private ObjectMapper objectMapper;
	private File datosJson;
	private ValidarPrestamosAnterioresCommand validarPrestamosAnterioresCmd;

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
		
		this.objectMapper = new ObjectMapper();
		this.datosJson = new File("src/test/resources/ValidarPrestamosAnteriores.json");
		this.validarPrestamosAnterioresCmd = new ValidarPrestamosAnterioresCommand();
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterEach
	void tearDown() throws Exception {
		this.objectMapper = null;
		this.datosJson = null;
		this.validarPrestamosAnterioresCmd = null;
	}

	/**
	 * Test method for {@link com.righttek.ts.solicitarprestamo.service.command.business.ValidarPrestamosAnterioresCommand#execute(com.righttek.gotalent.comun.patrones.command.IParam)}.
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 * @throws BusinessException 
	 */
	@Test
	void testExecuteValidarPrestamosAnterioresExcedido() throws JsonParseException, JsonMappingException, IOException, BusinessException {
		ValidarPrestamosAnterioresDTO validarPrestamosAnterioresDTO = objectMapper.readValue(datosJson, new TypeReference<List<ValidarPrestamosAnterioresDTO>>() {}).get(0);
		assertThrows(BusinessException.class, () -> {
			validarPrestamosAnterioresCmd.execute(validarPrestamosAnterioresDTO);
		  });
	}
	
	/**
	 * Test method for {@link com.righttek.ts.solicitarprestamo.service.command.business.ValidarPrestamosAnterioresCommand#execute(com.righttek.gotalent.comun.patrones.command.IParam)}.
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 */
	@Test
	void testExecuteValidarPrestamosAnterioresOk() throws JsonParseException, JsonMappingException, IOException, BusinessException {
		ValidarPrestamosAnterioresDTO validarPrestamosAnterioresDTO = objectMapper.readValue(datosJson, new TypeReference<List<ValidarPrestamosAnterioresDTO>>() {}).get(1);
		assertNull(validarPrestamosAnterioresCmd.execute(validarPrestamosAnterioresDTO));
	}

}
