package com.righttek.ts.solicitarprestamo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SolicitarPrestamoTsApplicationTests {

	@Test
	void contextLoads() {
	}

}
