/**
 * 
 */
package com.righttek.ts.solicitarprestamo.service.command.business;

import static org.assertj.core.api.Assertions.assertThatObject;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.righttek.gotalent.comun.exception.BusinessException;
import com.righttek.ts.solicitarprestamo.controller.dto.ValidarPrestamoDTO;

class ValidarPrestamoCommandTest {
	
	private ObjectMapper objectMapper;
	private File datosJson;
	private ValidarPrestamoCommand validarPrestamoCmd;

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
		
		this.objectMapper = new ObjectMapper();
		this.datosJson = new File("src/test/resources/ValidarPrestamo.json");
		this.validarPrestamoCmd = new ValidarPrestamoCommand();
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterEach
	void tearDown() throws Exception {
		this.objectMapper = null;
		this.datosJson = null;
		this.validarPrestamoCmd = null;
	}

	/**
	 * Test method for {@link com.righttek.ts.solicitarprestamo.service.command.business.ValidarPrestamoCommand#execute(com.righttek.gotalent.comun.patrones.command.IParam)}.
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 * @throws BusinessException 
	 */
	@Test
	void testExecuteValidarPrestamoValorExcedido() throws JsonParseException, JsonMappingException, IOException, BusinessException {
		ValidarPrestamoDTO validarPrestamoDTO = objectMapper.readValue(datosJson, new TypeReference<List<ValidarPrestamoDTO>>() {}).get(0);
		assertThrows(BusinessException.class, () -> {
			validarPrestamoCmd.execute(validarPrestamoDTO);
		  });
	}
	
	/**
	 * Test method for {@link com.righttek.ts.solicitarprestamo.service.command.business.ValidarPrestamoCommand#execute(com.righttek.gotalent.comun.patrones.command.IParam)}.
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 * @throws BusinessException 
	 */
	@Test
	void testExecuteValidarPrestamoFechaPagoExcedida() throws JsonParseException, JsonMappingException, IOException, BusinessException {
		ValidarPrestamoDTO validarPrestamoDTO = objectMapper.readValue(datosJson, new TypeReference<List<ValidarPrestamoDTO>>() {}).get(1);
		assertThrows(BusinessException.class, () -> {
			validarPrestamoCmd.execute(validarPrestamoDTO);
		  });
	}
	
	/**
	 * Test method for {@link com.righttek.ts.solicitarprestamo.service.command.business.ValidarPrestamoCommand#execute(com.righttek.gotalent.comun.patrones.command.IParam)}.
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 */
	@Test
	void testExecuteValidarPrestamoOk() throws JsonParseException, JsonMappingException, IOException, BusinessException {
		ValidarPrestamoDTO validarPrestamoDTO = objectMapper.readValue(datosJson, new TypeReference<List<ValidarPrestamoDTO>>(){}).get(2);	
		assertThatObject(validarPrestamoCmd.execute(validarPrestamoDTO));
	}

}
