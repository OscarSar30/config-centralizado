package com.righttek.gotalent.modelo_canonico;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.validation.constraints.Pattern;


public class SolicitudPermisoType extends SolicitudBaseType{
	
	@org.springframework.format.annotation.DateTimeFormat(iso = org.springframework.format.annotation.DateTimeFormat.ISO.DATE)
	private Date fechaPermiso;
	
	@Pattern(regexp = "^([0-1]?[0-9]|[2][0-3]):([0-5][0-9])(:[0-5][0-9])?$")
	private String horaDesde;
	
	@Pattern(regexp = "^([0-1]?[0-9]|[2][0-3]):([0-5][0-9])(:[0-5][0-9])?$")
	private String horaHasta;
	
	private String observacion;
	private List<AdjuntoType> rutaAdjunto;
	private TipoPermisoType tipoPermiso;
	
	/**
	 * @return the fechaPermiso
	 */
	public Date getFechaPermiso() {
		return fechaPermiso;
	}
	/**
	 * @param fechaPermiso the fechaPermiso to set
	 */
	public void setFechaPermiso(Date fechaPermiso) {
		this.fechaPermiso = fechaPermiso;
	}
	/**
	 * @return the horaDesde
	 */
	public String getHoraDesde() {
		return horaDesde;
	}
	/**
	 * @param horaDesde the horaDesde to set
	 */
	public void setHoraDesde(String horaDesde) {
		this.horaDesde = horaDesde;
	}
	/**
	 * @return the horaHasta
	 */
	public String getHoraHasta() {
		return horaHasta;
	}
	/**
	 * @param horaHasta the horaHasta to set
	 */
	public void setHoraHasta(String horaHasta) {
		this.horaHasta = horaHasta;
	}
	/**
	 * @return the observacion
	 */
	public String getObservacion() {
		return observacion;
	}
	/**
	 * @param observacion the observacion to set
	 */
	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}

	public  SolicitudPermisoType addRutaAdjunto (AdjuntoType rutaAdjunto) {
	    if (this.rutaAdjunto == null) {
	      this.rutaAdjunto = new ArrayList<>();
	    }
	    this.rutaAdjunto.add(rutaAdjunto);
	    return this;
	  }
	
	public List<AdjuntoType> getRutaAdjunto() {
		return rutaAdjunto;
	}
	public void setRutaAdjunto(List<AdjuntoType> rutaAdjunto) {
		this.rutaAdjunto = rutaAdjunto;
	}
	
	/**
	 * @return the tipoPermiso
	 */
	public TipoPermisoType getTipoPermiso() {
		return tipoPermiso;
	}
	/**
	 * @param tipoPermiso the tipoPermiso to set
	 */
	public void setTipoPermiso(TipoPermisoType tipoPermiso) {
		this.tipoPermiso = tipoPermiso;
	}
	
}