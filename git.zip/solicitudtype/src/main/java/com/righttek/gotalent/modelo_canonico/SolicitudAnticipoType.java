/**
 * 
 */
package com.righttek.gotalent.modelo_canonico;

/**
 * @author Oscar Sarcos
 *
 */
public class SolicitudAnticipoType extends SolicitudBaseType{
   
	private String comentario;
	private double montoDisponible;
	private double valorAnticipo;
	

	/**
	 * @return the comentario
	 */
	public String getComentario() {
		return comentario;
	}

	/**
	 * @param comentario the comentario to set
	 */
	public void setComentario(String comentario) {
		this.comentario = comentario;
	}

	/**
	 * @return the valorAnticipo
	 */
	public double getValorAnticipo() {
		return valorAnticipo;
	}

	/**
	 * @param valorAnticipo the valorAnticipo to set
	 */
	public void setValorAnticipo(double valorAnticipo) {
		this.valorAnticipo = valorAnticipo;
	}

	/**
	 * @return the montoDisponible
	 */
	public double getMontoDisponible() {
		return montoDisponible;
	}

	/**
	 * @param montoDisponible the montoDisponible to set
	 */
	public void setMontoDisponible(double montoDisponible) {
		this.montoDisponible = montoDisponible;
	}

}