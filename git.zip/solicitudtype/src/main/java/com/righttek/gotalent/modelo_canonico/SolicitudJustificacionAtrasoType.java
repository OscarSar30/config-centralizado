package com.righttek.gotalent.modelo_canonico;

import java.util.List;

import javax.validation.constraints.Pattern;

/**
 * @author amacias
 *
 */
public class SolicitudJustificacionAtrasoType extends SolicitudBaseType {
	
	
	@Pattern(regexp = "^([0-1]?[0-9]|[2][0-3]):([0-5][0-9])(:[0-5][0-9])?$")
	private String horaDesde;
	
	@Pattern(regexp = "^([0-1]?[0-9]|[2][0-3]):([0-5][0-9])(:[0-5][0-9])?$")
	private String horaHasta;
	
	private MarcacionType marcacion;
	private List<AdjuntoType> rutaAdjunto;
	
	public MarcacionType getMarcacion() {
		return marcacion;
	}
	public void setMarcacion(MarcacionType marcacion) {
		this.marcacion = marcacion;
	}
	public List<AdjuntoType> getRutaAdjunto() {
		return rutaAdjunto;
	}
	public void setRutaAdjunto(List<AdjuntoType> rutaAdjunto) {
		this.rutaAdjunto = rutaAdjunto;
	}
	/**
	 * @return the horaDesde
	 */
	public String getHoraDesde() {
		return horaDesde;
	}
	/**
	 * @param horaDesde the horaDesde to set
	 */
	public void setHoraDesde(String horaDesde) {
		this.horaDesde = horaDesde;
	}
	/**
	 * @return the horaHasta
	 */
	public String getHoraHasta() {
		return horaHasta;
	}
	/**
	 * @param horaHasta the horaHasta to set
	 */
	public void setHoraHasta(String horaHasta) {
		this.horaHasta = horaHasta;
	}
	
	

}
