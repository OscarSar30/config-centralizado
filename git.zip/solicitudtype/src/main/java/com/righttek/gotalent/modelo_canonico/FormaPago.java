package com.righttek.gotalent.modelo_canonico;

public enum FormaPago {
	EFECTIVO("EFECTIVO"),
	REEMBOLSO("EFECTIVO");
	
	private String value;
	
	FormaPago (String value){
		this.value = value;
	}
	
	@Override
	public String toString() {
		return value;
	}
}