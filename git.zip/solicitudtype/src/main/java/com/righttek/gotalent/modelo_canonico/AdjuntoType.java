package com.righttek.gotalent.modelo_canonico;

/**
 * @author AnibalG
 *
 */
public class AdjuntoType {
	private String nombreOriginalArchivo;
	private String rutaAdjunto;
	/**
	 * @return the nombreOriginalArchivo
	 */
	public String getNombreOriginalArchivo() {
		return nombreOriginalArchivo;
	}
	/**
	 * @param nombreOriginalArchivo the nombreOriginalArchivo to set
	 */
	public void setNombreOriginalArchivo(String nombreOriginalArchivo) {
		this.nombreOriginalArchivo = nombreOriginalArchivo;
	}
	/**
	 * @return the rutaAdjunto
	 */
	public String getRutaAdjunto() {
		return rutaAdjunto;
	}
	/**
	 * @param rutaAdjunto the rutaAdjunto to set
	 */
	public void setRutaAdjunto(String rutaAdjunto) {
		this.rutaAdjunto = rutaAdjunto;
	}
	
	
}
