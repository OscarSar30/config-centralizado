package com.righttek.gotalent.modelo_canonico;


public class SolicitudUbicacionType extends SolicitudBaseType{
	
	private String descripcionUbicacion;
	private String latitud;
	private String longitud;
	
	
	/**
	 * @return the descripcionUbicacion
	 */
	public String getDescripcionUbicacion() {
		return descripcionUbicacion;
	}
	/**
	 * @param descripcionUbicacion the descripcionUbicacion to set
	 */
	public void setDescripcionUbicacion(String descripcionUbicacion) {
		this.descripcionUbicacion = descripcionUbicacion;
	}
	/**
	 * @return the latitud
	 */
	public String getLatitud() {
		return latitud;
	}
	/**
	 * @param latitud the latitud to set
	 */
	public void setLatitud(String latitud) {
		this.latitud = latitud;
	}
	/**
	 * @return the longitud
	 */
	public String getLongitud() {
		return longitud;
	}
	/**
	 * @param longitud the longitud to set
	 */
	public void setLongitud(String longitud) {
		this.longitud = longitud;
	}
	
}
