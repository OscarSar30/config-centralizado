package com.righttek.gotalent.modelo_canonico;

public enum EstadoSolicitud {
	
	
	PENDIENTE("PENDIENTE"),
	APROBADA("APROBADA"),
	RECHAZADA("RECHAZADA");
	
	private String value;
	
	EstadoSolicitud(String value){
		this.value = value;
	}
	 public String getValue() {
	      return value;
	    }

	@Override
	public String toString() {
	      return String.valueOf(value);
	    }

	public static EstadoSolicitud fromValue(String value) {
	      for (EstadoSolicitud b : EstadoSolicitud.values()) {
	        if (b.value.equals(value)) {
	          return b;
	        }
	      }
	      throw new IllegalArgumentException("Unexpected value '" + value + "'");
	    }
}
