package com.righttek.gotalent.modelo_canonico;

public class SolicitudPrestamoType extends SolicitudBaseType{
	
	private Double montoDisponible;
	private PrestamoType prestamo;
	private String rolNombre;
	private int idSolicitudLegado;
	
	/**
	 * @return the montoDisponible
	 */
	public Double getMontoDisponible() {
		return montoDisponible;
	}
	/**
	 * @param montoDisponible the montoDisponible to set
	 */
	public void setMontoDisponible(Double montoDisponible) {
		this.montoDisponible = montoDisponible;
	}
	/**
	 * @return the prestamo
	 */
	public PrestamoType getPrestamo() {
		return prestamo;
	}
	/**
	 * @param prestamo the prestamo to set
	 */
	public void setPrestamo(PrestamoType prestamo) {
		this.prestamo = prestamo;
	}
	/**
	 * @return the rolNombre
	 */
	public String getRolNombre() {
		return rolNombre;
	}
	/**
	 * @param rolNombre the rolNombre to set
	 */
	public void setRolNombre(String rolNombre) {
		this.rolNombre = rolNombre;
	}
	/**
	 * @return the idSolicitudLegado
	 */
	public int getIdSolicitudLegado() {
		return idSolicitudLegado;
	}
	/**
	 * @param idSolicitudLegado the idSolicitudLegado to set
	 */
	public void setIdSolicitudLegado(int idSolicitudLegado) {
		this.idSolicitudLegado = idSolicitudLegado;
	}

}
