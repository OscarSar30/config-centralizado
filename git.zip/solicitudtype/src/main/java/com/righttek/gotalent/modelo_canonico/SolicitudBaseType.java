/**
 * 
 */
package com.righttek.gotalent.modelo_canonico;

import java.util.Date;
import java.util.UUID;

import org.springframework.format.annotation.DateTimeFormat;

/**
 * @author RGT_Capacitacin_03
 *
 */
public class SolicitudBaseType {
	
	private String empleadoAprobadorId;
	private String empleadoId;
	private String empresaId;
	private EstadoSolicitud estado;
	private String estadoFlujoAprobacion;
	
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date fechaCreacion;
	
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date fechaModificacion;
	
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE, pattern = "yyyy-MM-dd")
	private Date fechaSolicitud;
	private UUID id;
	private String justificacion;
	private String nombreEmpleado;
	private String observacion;
	private String tipo;
	private String usuarioCreacion;
	private String usuarioId;
	private String usuarioModificacion;
	/**
	 * @return the empleadoId
	 */
	public String getEmpleadoId() {
		return empleadoId;
	}
	/**
	 * @param empleadoId the empleadoId to set
	 */
	public void setEmpleadoId(String empleadoId) {
		this.empleadoId = empleadoId;
	}
	/**
	 * @return the empresaId
	 */
	public String getEmpresaId() {
		return empresaId;
	}
	/**
	 * @param empresaId the empresaId to set
	 */
	public void setEmpresaId(String empresaId) {
		this.empresaId = empresaId;
	}
	/**
	 * @return the estado
	 */
	public EstadoSolicitud getEstado() {
		return estado;
	}
	/**
	 * @param estado the estado to set
	 */
	public void setEstado(EstadoSolicitud estado) {
		this.estado = estado;
	}
	/**
	 * @return the estadoFlujoAprobacion
	 */
	public String getEstadoFlujoAprobacion() {
		return estadoFlujoAprobacion;
	}
	/**
	 * @param estadoFlujoAprobacion the estadoFlujoAprobacion to set
	 */
	public void setEstadoFlujoAprobacion(String estadoFlujoAprobacion) {
		this.estadoFlujoAprobacion = estadoFlujoAprobacion;
	}
	/**
	 * @return the fechaCreacion
	 */
	public Date getFechaCreacion() {
		return fechaCreacion;
	}
	/**
	 * @param fechaCreacion the fechaCreacion to set
	 */
	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}
	/**
	 * @return the fechaModificacion
	 */
	public Date getFechaModificacion() {
		return fechaModificacion;
	}
	/**
	 * @param fechaModificacion the fechaModificacion to set
	 */
	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}
	/**
	 * @return the fechaSolicitud
	 */
	public Date getFechaSolicitud() {
		return fechaSolicitud;
	}
	/**
	 * @param fechaSolicitud the fechaSolicitud to set
	 */
	public void setFechaSolicitud(Date fechaSolicitud) {
		this.fechaSolicitud = fechaSolicitud;
	}
	/**
	 * @return the id
	 */
	public UUID getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(UUID id) {
		this.id = id;
	}
	/**
	 * @return the justificacion
	 */
	public String getJustificacion() {
		return justificacion;
	}
	/**
	 * @param justificacion the justificacion to set
	 */
	public void setJustificacion(String justificacion) {
		this.justificacion = justificacion;
	}
	/**
	 * @return the nombreEmpleado
	 */
	public String getNombreEmpleado() {
		return nombreEmpleado;
	}
	/**
	 * @param nombreEmpleado the nombreEmpleado to set
	 */
	public void setNombreEmpleado(String nombreEmpleado) {
		this.nombreEmpleado = nombreEmpleado;
	}
	/**
	 * @return the observacion
	 */
	public String getObservacion() {
		return observacion;
	}
	/**
	 * @param observacion the observacion to set
	 */
	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}
	/**
	 * @return the tipo
	 */
	public String getTipo() {
		return tipo;
	}
	/**
	 * @param tipo the tipo to set
	 */
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	/**
	 * @return the usuarioCreacion
	 */
	public String getUsuarioCreacion() {
		return usuarioCreacion;
	}
	/**
	 * @param usuarioCreacion the usuarioCreacion to set
	 */
	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}
	/**
	 * @return the usuarioId
	 */
	public String getUsuarioId() {
		return usuarioId;
	}
	/**
	 * @param usuarioId the usuarioId to set
	 */
	public void setUsuarioId(String usuarioId) {
		this.usuarioId = usuarioId;
	}
	/**
	 * @return the usuarioModificacion
	 */
	public String getUsuarioModificacion() {
		return usuarioModificacion;
	}
	/**
	 * @param usuarioModificacion the usuarioModificacion to set
	 */
	public void setUsuarioModificacion(String usuarioModificacion) {
		this.usuarioModificacion = usuarioModificacion;
	}
	/**
	 * @return the empleadoAprobadorId
	 */
	public String getEmpleadoAprobadorId() {
		return empleadoAprobadorId;
	}
	/**
	 * @param empleadoAprobadorId the empleadoAprobadorId to set
	 */
	public void setEmpleadoAprobadorId(String empleadoAprobadorId) {
		this.empleadoAprobadorId = empleadoAprobadorId;
	}
	
	
}
