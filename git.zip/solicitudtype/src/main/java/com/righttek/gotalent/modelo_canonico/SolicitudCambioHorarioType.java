/**
 * 
 */
package com.righttek.gotalent.modelo_canonico;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * @author RGT_Capacitaci�n_03
 *
 */
public class SolicitudCambioHorarioType extends SolicitudBaseType{
	
	private Date fechaDesde;
	private Date fechaHasta;
	private List<HorarioType> horarioActualEmpleado;
	private HorarioEmpleadoType horarioEmpleado;
	private List<AdjuntoType> rutaAdjunto;
	
	
	/**
	 * @return the fechaDesde
	 */
	public Date getFechaDesde() {
		return fechaDesde;
	}
	/**
	 * @param fechaDesde the fechaDesde to set
	 */
	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}
	/**
	 * @return the fechaHasta
	 */
	public Date getFechaHasta() {
		return fechaHasta;
	}
	/**
	 * @param fechaHasta the fechaHasta to set
	 */
	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}
	/**
	 * @return the horarioEmpleado
	 */
	public HorarioEmpleadoType getHorarioEmpleado() {
		return horarioEmpleado;
	}
	/**
	 * @param horarioEmpleado the horarioEmpleado to set
	 */
	public void setHorarioEmpleado(HorarioEmpleadoType horarioEmpleado) {
		this.horarioEmpleado = horarioEmpleado;
	}
	
	
	public  SolicitudCambioHorarioType addRutaAdjunto (AdjuntoType rutaAdjunto) {
	    if (this.rutaAdjunto == null) {
	      this.rutaAdjunto = new ArrayList<>();
	    }
	    this.rutaAdjunto.add(rutaAdjunto);
	    return this;
	}
	
	public List<AdjuntoType> getRutaAdjunto() {
		return rutaAdjunto;
	}
	public void setRutaAdjunto(List<AdjuntoType> rutaAdjunto) {
		this.rutaAdjunto = rutaAdjunto;
	}
		
	
	public List<HorarioType> getHorarioActualEmpleado() {
		return horarioActualEmpleado;
	}
	public void setHorarioActualEmpleado(List<HorarioType> horarioActualEmpleado) {
		this.horarioActualEmpleado = horarioActualEmpleado;
	}
	 
	
}