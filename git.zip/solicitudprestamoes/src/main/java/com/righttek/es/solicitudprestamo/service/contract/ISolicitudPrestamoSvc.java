package com.righttek.es.solicitudprestamo.service.contract;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Min;

import com.righttek.gotalent.comun.exception.ApplicationException;
import com.righttek.gotalent.modelo_canonico.EstadoSolicitud;
import com.righttek.gotalent.modelo_canonico.SolicitudPrestamoType;



public interface ISolicitudPrestamoSvc {
	
	public SolicitudPrestamoType crearSolicitudPrestamo(@Valid SolicitudPrestamoType solicitudPrestamoType) throws ApplicationException;
	public SolicitudPrestamoType actualizarSolicitudPrestamo(SolicitudPrestamoType solicitudPrestamoType) throws ApplicationException;
	public List<SolicitudPrestamoType> consultarSolicitudesPrestamo(String empresaId,
			@Valid @Min(1) Integer cantidadRegistros);
	public List<SolicitudPrestamoType> consultarSolicitudesPrestamoPorEstado(EstadoSolicitud estadoSolicitud);
	public List<SolicitudPrestamoType> consultarSolicitudesPrestamoPorFecha(String empresaId, Date fechaDesde,
			Date fechaHasta);
	public List<SolicitudPrestamoType>consultarSolicitudPrestamoPorEmpleado(String empleadoId, String fechaDesde, String fechaHasta)  throws ParseException; 
	
}
