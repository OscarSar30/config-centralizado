package com.righttek.es.solicitudprestamo.repository.model;

import java.io.Serializable;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "solicitud_prestamo")
public class SolicitudPrestamo extends SolicitudBase implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Column(name = "monto_disponible")
	private Double montoDisponible;
	
	@OneToOne(optional = false, cascade = CascadeType.ALL, fetch=FetchType.EAGER)
	@JoinColumn(name="prestamo", referencedColumnName = "id", nullable = false)
	private Prestamo prestamo;
	
	@Column(name = "rol_nombre")
	private String rolNombre;
	
	@Column(name = "id_solicitud_legado")
	private int idSolicitudLegado;

	/**
	 * @return the montoDisponible
	 */
	public Double getMontoDisponible() {
		return montoDisponible;
	}

	/**
	 * @param montoDisponible the montoDisponible to set
	 */
	public void setMontoDisponible(Double montoDisponible) {
		this.montoDisponible = montoDisponible;
	}

	/**
	 * @return the prestamo
	 */
	public Prestamo getPrestamo() {
		return prestamo;
	}

	/**
	 * @param prestamo the prestamo to set
	 */
	public void setPrestamo(Prestamo prestamo) {
		this.prestamo = prestamo;
	}

	/**
	 * @return the rolNombre
	 */
	public String getRolNombre() {
		return rolNombre;
	}

	/**
	 * @param rolNombre the rolNombre to set
	 */
	public void setRolNombre(String rolNombre) {
		this.rolNombre = rolNombre;
	}

	/**
	 * @return the idSolicitudLegado
	 */
	public int getIdSolicitudLegado() {
		return idSolicitudLegado;
	}

	/**
	 * @param idSolicitudLegado the idSolicitudLegado to set
	 */
	public void setIdSolicitudLegado(int idSolicitudLegado) {
		this.idSolicitudLegado = idSolicitudLegado;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
