package com.righttek.es.solicitudprestamo.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Min;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.righttek.es.solicitudprestamo.repository.contract.ISolicitudPrestamoRepository;
import com.righttek.es.solicitudprestamo.repository.model.SolicitudPrestamo;
import com.righttek.es.solicitudprestamo.service.contract.ISolicitudPrestamoSvc;
import com.righttek.es.solicitudprestamo.utils.convert.SolicitudPrestamoConvert;
import com.righttek.gotalent.comun.exception.ApplicationException;
import com.righttek.gotalent.comun.exception.TipoError;
import com.righttek.gotalent.modelo_canonico.EstadoSolicitud;
import com.righttek.gotalent.modelo_canonico.SolicitudPrestamoType;
@Service
public class SolicitudPrestamoSvc implements ISolicitudPrestamoSvc {
	@Autowired
	ISolicitudPrestamoRepository solicitudPrestamoRepository;

	@Override
	public SolicitudPrestamoType crearSolicitudPrestamo(@Valid SolicitudPrestamoType solicitudPrestamoType) throws ApplicationException {
		solicitudPrestamoType.setId(null);
		solicitudPrestamoType.getPrestamo().setId(null);
		SolicitudPrestamo solicitudPrestamo = solicitudPrestamoRepository.save(SolicitudPrestamoConvert.typeToModel(solicitudPrestamoType));
		return solicitudPrestamo == null ? null :
				SolicitudPrestamoConvert.modelToType(solicitudPrestamo);
	}

	@Override
	public SolicitudPrestamoType actualizarSolicitudPrestamo(SolicitudPrestamoType solicitudPrestamoType) throws ApplicationException {
		if(!solicitudPrestamoRepository.existsById(solicitudPrestamoType.getId())) {
			throw new ApplicationException(String.format("La Solicitud Prestamo con id: [%s] no existe",solicitudPrestamoType.getId().toString()),TipoError.NO_ENCONTRADO);
		}
		SolicitudPrestamo solicitudPrestamo = solicitudPrestamoRepository.save(SolicitudPrestamoConvert.typeToModel(solicitudPrestamoType));
		return solicitudPrestamo == null ? null :
			SolicitudPrestamoConvert.modelToType(solicitudPrestamo);

	}


	@Override
	public List<SolicitudPrestamoType> consultarSolicitudesPrestamo(String empresaId,
			@Valid @Min(1) Integer cantidadRegistros) {
		List<SolicitudPrestamoType> solicitudPrestamoType = SolicitudPrestamoConvert.listModelToType(solicitudPrestamoRepository.consultarSolicitudesPrestamo(empresaId, cantidadRegistros));
		return solicitudPrestamoType;
	}
	
	@Override
	public List<SolicitudPrestamoType> consultarSolicitudesPrestamoPorFecha(String empresaId, Date fechaDesde,
			Date fechaHasta) {
		List<SolicitudPrestamoType> solicitudPrestamoType = SolicitudPrestamoConvert.listModelToType(solicitudPrestamoRepository.consultarSolicitudesPrestamoPorFecha(empresaId, fechaDesde, fechaHasta));
		return solicitudPrestamoType;
	}

	@Override
	public List<SolicitudPrestamoType> consultarSolicitudesPrestamoPorEstado(EstadoSolicitud estadoSolicitud) {
		List<SolicitudPrestamoType> solicitudPrestamoType = SolicitudPrestamoConvert.listModelToType(solicitudPrestamoRepository.consultarSolicitudesPrestamoPorEstado(estadoSolicitud));
		return solicitudPrestamoType;
	}

	@Override
	public List<SolicitudPrestamoType> consultarSolicitudPrestamoPorEmpleado(String empleadoId, String fechaDesde,
			String fechaHasta) throws ParseException {
		SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd");
		Date fechaIni = formatoFecha.parse(fechaDesde);
		Date fechaFin = formatoFecha.parse(fechaHasta);
		List<SolicitudPrestamoType> solicitudPrestamo = SolicitudPrestamoConvert.listModelToType(solicitudPrestamoRepository.consultarSolicitudesPrestamoPorEmpleado(empleadoId, fechaIni, fechaFin));
		return solicitudPrestamo;
	}

	
}
