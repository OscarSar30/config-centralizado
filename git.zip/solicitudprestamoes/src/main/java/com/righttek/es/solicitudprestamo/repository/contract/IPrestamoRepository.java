package com.righttek.es.solicitudprestamo.repository.contract;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.righttek.es.solicitudprestamo.repository.model.Prestamo;

@Repository
public interface IPrestamoRepository extends JpaRepository<Prestamo, UUID>{

}
