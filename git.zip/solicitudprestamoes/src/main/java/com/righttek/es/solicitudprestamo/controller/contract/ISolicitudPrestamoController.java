package com.righttek.es.solicitudprestamo.controller.contract;

import java.util.Date;

import javax.validation.Valid;
import javax.validation.constraints.Min;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.righttek.gotalent.comun.utilitarios.RespuestaType;
import com.righttek.gotalent.modelo_canonico.EstadoSolicitud;
import com.righttek.gotalent.modelo_canonico.SolicitudPrestamoType;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * @author jesusvallejo
 *
 */
/**
 * @author jesusvallejo
 *
 */
/**
 * @author jesusvallejo
 *
 */
@Validated
@Tag(name = "SolicitudPrestamoESv1", description = "Servicio Entidad Solicitud Prestamo")
public interface ISolicitudPrestamoController {
	
	 /**
     * 1
     * POST /api/es/solicitud/prestamo/v1 : Crear Solicitud Prestamo
     * Crear una nueva solicitud de Prestamo
     *
     * @param solicitudPrestamoType
     * @return OK (status code 200)
     *         or Bad Request (status code 400)
     *         or Internal Server Error (status code 500)
     */
    @Operation(method = "Crear Solicitud Prestamo", operationId = "crearSolicitudPrestamo", description = "Crear una nueva solicitud de Prestamo", tags={ "SolicitudPrestamoESv1", }, summary = "Crear una nueva solicitud de Prestamo")
    @ApiResponses(value = { 
            @ApiResponse(responseCode = "201", description =  "Created", content = @Content(schema = @Schema(implementation = RespuestaType.class))),
            @ApiResponse(responseCode = "400", description =  "Bad Request", content = @Content(schema = @Schema(implementation = RespuestaType.class))),
            @ApiResponse(responseCode = "500", description =  "Internal Server Error", content = @Content(schema = @Schema(implementation = RespuestaType.class))) })
    @PostMapping(value = "/solicitud/prestamo/v1",
        produces = "application/json; charset=UTF-8", 
        consumes = "application/json; charset=UTF-8")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(description = "Crear Solicitud Prestamo",required = true,content = @Content(schema = @Schema(implementation = SolicitudPrestamoType.class)))
    ResponseEntity<?> crearSolicitudPrestamo(@Valid @RequestBody(required = false) SolicitudPrestamoType solicitudPrestamoType);
    
    /**
     * 2
     * PUT /solicitud/prestamo/v1 : Actualizar Solicitud Prestamo
     * Actualizar datos de solicitud de Prestamo
     *
     * @param solicitudPrestamoType  (optional)
     * @return OK (status code 200)
     *         or Bad Request (status code 400)
     *         or Internal Server Error (status code 500)
     */
    @Operation(method = "Actualizar Solicitud Prestamo", operationId = "actualizarSolicitudPrestamo", description = "Actualizar datos de solicitud de Prestamo", tags={ "SolicitudPrestamoESv1", }, summary = "Actualizar datos de solicitud de Prestamo")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description =  "OK", content = @Content(schema = @Schema(implementation = RespuestaType.class))),
        @ApiResponse(responseCode = "400", description =  "Bad Request", content = @Content(schema = @Schema(implementation = RespuestaType.class))),
        @ApiResponse(responseCode = "404", description =  "Not Found", content = @Content(schema = @Schema(implementation = RespuestaType.class))),
        @ApiResponse(responseCode = "500", description =  "Internal Server Error", content = @Content(schema = @Schema(implementation = RespuestaType.class))) })
    @PutMapping(value = "/solicitud/prestamo/v1",
        produces = "application/json; charset=UTF-8", 
        consumes = "application/json; charset=UTF-8")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(description = "Actualizar Solicitud Prestamo",required = true,content = @Content(schema = @Schema(implementation = SolicitudPrestamoType.class)))
    ResponseEntity<?> actualizarSolicitudPrestamo(@Valid @RequestBody(required = false) SolicitudPrestamoType solicitudPrestamoType);
    
    /** 
     * 3
     * GET /api/es/solicitud/prestamo/v1/{empresaId}/{cantidadRegistros} : ConsultarSolicitudesPrestamo 
     * 
     * ConsultarSolicitudesPrestamo 
     *
     * @return OK (status code 200)
     * 		   or No Content (status code 204)
     *         or Bad Request (status code 400)
     *         or Internal Server Error (status code 500)
     */
    @Operation(method = "Consultar Solicitudes Prestamo",operationId = "consultarSolicitudesPrestamo", description = "Consultar Solicitudes Prestamo", tags={ "SolicitudPrestamoESv1", }, summary = "Devuelve las solicitudes Prestamo por empresa ID")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description =  "OK", content = @Content( array = @ArraySchema( schema = @Schema(implementation = SolicitudPrestamoType.class)))),
        @ApiResponse(responseCode = "204", description =  "No Content", content = @Content(schema = @Schema(implementation = RespuestaType.class))),
        @ApiResponse(responseCode = "400", description =  "Bad Request", content = @Content(schema = @Schema(implementation = RespuestaType.class))),
        @ApiResponse(responseCode = "500", description =  "Internal Server Error", content = @Content(schema = @Schema(implementation = RespuestaType.class))) })
    @GetMapping(value = "/solicitud/prestamo/v1/{empresaId}/{cantidadRegistros}",
        produces = "application/json; charset=UTF-8")
    @Parameters (value = {
			@Parameter (name = "empresaId", description = "ID empresa", example = "1004"),
			@Parameter (name = "cantidadRegistros", description = "Cantidad de registros a mostrar", example = "10")
	})
    ResponseEntity<?> consultarSolicitudesPrestamo (@PathVariable (name = "empresaId", required = true) String empresaId, 
												   @PathVariable (name = "cantidadRegistros", required = true) @Valid @Min(1) Integer cantidadRegistros);
    
    /** 
     * 4
     * GET /api/es/solicitud/prestamo/fecha/v1/{empresaId}/{fechaDesde}/{fechaHasta} : ConsultarSolicitudPrestamoPorFecha 
     * 
     * ConsultarSolicitudPrestamoPorFecha
     *
     * @return OK (status code 200)
     * 		   or No Content (status code 204)
     *         or Bad Request (status code 400)
     *         or Internal Server Error (status code 500)
     */
    @Operation(method = "Consultar Solicitudes Prestamo por Fecha",operationId = "consultarSolicitudesPrestamoPorFecha", description = "Consultar Solicitudes Prestamo Por Fecha", tags={ "SolicitudPrestamoESv1", }, summary = "consultarSolicitudesPrestamoPorFecha")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description =  "OK", content = @Content( array = @ArraySchema( schema = @Schema(implementation = SolicitudPrestamoType.class)))),
        @ApiResponse(responseCode = "204", description =  "No Content", content = @Content(schema = @Schema(implementation = RespuestaType.class))),
        @ApiResponse(responseCode = "400", description =  "Bad Request", content = @Content(schema = @Schema(implementation = RespuestaType.class))),
        @ApiResponse(responseCode = "500", description =  "Internal Server Error", content = @Content(schema = @Schema(implementation = RespuestaType.class))) })
    @GetMapping(value = "/solicitud/prestamo/fecha/v1/{empresaId}/{fechaDesde}/{fechaHasta}",
        produces = "application/json; charset=UTF-8")
    @Parameters (value = {
			@Parameter (name = "empresaId", description = "empresa ID", example = "1004"),
			@Parameter (name = "fechaDesde", description = "Fecha desde", example = "2020-01-01"),
			@Parameter (name = "fechaHasta", description = "Fecha hasta", example = "2020-12-31")
	})
    ResponseEntity<?> consultarSolicitudesPrestamoPorFecha (
    		@PathVariable (name = "empresaId", required = true) String empresaId, 
    		@PathVariable (name = "fechaDesde", required = true)@DateTimeFormat(pattern = "yyyy-MM-dd") Date fechaDesde, 
    		@PathVariable (name = "fechaHasta", required = true) @DateTimeFormat(pattern = "yyyy-MM-dd") Date fechaHasta);
    
    
    /** 
     * 5
     * GET /api/es/solicitud/prestamo/estado/v1/{estadoSolicitud} : ConsultarSolicitudPrestamoPorEstado 
     * 
     * ConsultarSolicitudPrestamoPorEstado
     *
     * @return OK (status code 200)
     * 		   or No Content (status code 204)
     *         or Bad Request (status code 400)
     *         or Internal Server Error (status code 500)
     */
    @Operation(method = "Consultar Solicitudes Prestamo por Estado",operationId = "consultarSolicitudPrestamoPorEstado", description = "Consultar Solicitudes Prestamo Por Estado", tags={ "SolicitudPrestamoESv1", }, summary = "consultarSolicitudPrestamoPorEstado")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description =  "OK", content = @Content( array = @ArraySchema( schema = @Schema(implementation = SolicitudPrestamoType.class)))),
        @ApiResponse(responseCode = "204", description =  "No Content", content = @Content(schema = @Schema(implementation = RespuestaType.class))),
        @ApiResponse(responseCode = "400", description =  "Bad Request", content = @Content(schema = @Schema(implementation = RespuestaType.class))),
        @ApiResponse(responseCode = "500", description =  "Internal Server Error", content = @Content(schema = @Schema(implementation = RespuestaType.class))) })
    @GetMapping(value = "/solicitud/prestamo/estado/v1/{estadoSolicitud}",
        produces = "application/json; charset=UTF-8")
    @Parameter (name = "estadoSolicitud", description = "Estado de solicitud Prestamo", example = "PENDIENTE")
    ResponseEntity<?> consultarSolicitudPrestamoPorEstado (
    		@PathVariable (name = "estadoSolicitud") EstadoSolicitud estadoSolicitud);
    

    
    
    /** 
     * 6
     * ConsultarSolicitudPrestamoPorEmpleado 
     * GET /api/es/solicitud/prestamo/empleado/fecha/v1/{empleadoId}/{fechaDesde}/{fechaHasta}
     *
     * @return OK (status code 200)
     * 		   or No Content (status code 204)
     *         or Bad Request (status code 400)
     *         or Internal Server Error (status code 500)
     */
    
    @Operation(method = "Consultar solicitudes prestamo por usuario", operationId = "consultarSolicitudPrestamosPor Usuario", description = "Capacidad que permite consultar las solicitudes por id de empleado y rango de fecha",tags = {"SolicitudPrestamoESv1",}, summary = "Consultar solicitud prestamo por id de empleado y rango de fecha")
    @ApiResponses(value = {
    		@ApiResponse(responseCode = "200", description = "OK", content = @Content(array = @ArraySchema(schema = @Schema(implementation = SolicitudPrestamoType.class)))),
    		@ApiResponse(responseCode = "204", description = "No Content", content = @Content(schema = @Schema(implementation = RespuestaType.class))),
    		@ApiResponse(responseCode = "400", description = "Bad request", content = @Content(schema = @Schema(implementation = RespuestaType.class))),
    		@ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(schema = @Schema(implementation = RespuestaType.class)))
    })
    @GetMapping(value = "/solicitud/prestamo/empleado/fecha/v1/{empleadoId}/{fechaDesde}/{fechaHasta}",produces = "application/json; charset=UTF-8")
    @Parameters(value = {
    		@Parameter(name = "empleadoId", description = "Id empleado",example = "1245"),
    		@Parameter(name = "fechaDesde", description = "Fecha desde",example = "2021-12-01"),
    		@Parameter(name = "fechaHasta", description = "Fecha hasta", example = "2021-12-31")
    })
    ResponseEntity<?>consultarSolicitudPrestamoPorEmpleado(
    		@PathVariable(name = "empleadoId",required = true) String empleadoId,
    		@PathVariable(name = "fechaDesde", required = true) String fechaDesde,
    		@PathVariable(name = "fechaHasta", required = true) String fechaHasta);
    
}




