package com.righttek.es.solicitudprestamo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SolicitudPrestamoEsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SolicitudPrestamoEsApplication.class, args);
	}

}
