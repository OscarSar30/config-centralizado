package com.righttek.es.solicitudprestamo.utils.convert;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;

import com.righttek.es.solicitudprestamo.repository.model.SolicitudPrestamo;
import com.righttek.gotalent.modelo_canonico.SolicitudPrestamoType;



public class SolicitudPrestamoConvert {
	public static final SolicitudPrestamoType modelToType(SolicitudPrestamo solicitudPrestamo) {
		return new ModelMapper().map(solicitudPrestamo, SolicitudPrestamoType.class);
		
	}

	public static final SolicitudPrestamo typeToModel(SolicitudPrestamoType solicitudPrestamoType) {
		return new ModelMapper().map(solicitudPrestamoType, SolicitudPrestamo.class);

	}
	
	public static final List<SolicitudPrestamoType> listModelToType(List<SolicitudPrestamo> solicitudPrestamos){
		//return solicitudPrestamos.stream().map(solicitudPrestamo -> modelToType(solicitudPrestamo)).collect(Collectors.toList());
		List<SolicitudPrestamoType> lspt= solicitudPrestamos.stream().map(solicitudPrestamo -> modelToType(solicitudPrestamo)).collect(Collectors.toList());
		return lspt;
	}
	
	public static final List<SolicitudPrestamo> listTypeToModel(List<SolicitudPrestamoType> solicitudPrestamos){
		//return solicitudPrestamos.stream().map(solicitudPrestamo -> modelToType(solicitudPrestamo)).collect(Collectors.toList());
		List<SolicitudPrestamo> lspt= solicitudPrestamos.stream().map(solicitudPrestamo -> typeToModel(solicitudPrestamo)).collect(Collectors.toList());
		return lspt;
	}
}
