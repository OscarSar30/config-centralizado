package com.righttek.es.solicitudprestamo.controller.impl;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Min;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.righttek.es.solicitudprestamo.controller.contract.ISolicitudPrestamoController;
import com.righttek.es.solicitudprestamo.service.contract.ISolicitudPrestamoSvc;
import com.righttek.es.solicitudprestamo.utils.SolicitudPrestamoValidator;
import com.righttek.gotalent.comun.constantes.MensajeDelSistema;
import com.righttek.gotalent.comun.exception.ApplicationException;
import com.righttek.gotalent.comun.utilitarios.RespuestaType;
import com.righttek.gotalent.modelo_canonico.EstadoSolicitud;
import com.righttek.gotalent.modelo_canonico.SolicitudPrestamoType;


@RestController
@RequestMapping("/api/es")
public class SolicitudPrestamoControllerImpl implements ISolicitudPrestamoController {
	private static final Logger LOGGER = LoggerFactory.getLogger(SolicitudPrestamoControllerImpl.class);

	@Autowired
	ISolicitudPrestamoSvc solicitudPrestamoSvc;

	@SuppressWarnings("unused")
	@Override
	public ResponseEntity<?> crearSolicitudPrestamo(@Valid SolicitudPrestamoType solicitudPrestamoType) {
		ResponseEntity<?> respuesta;
		try {
			LOGGER.info("INICIA CREAR SOLICITUD PRESTAMO");
			SolicitudPrestamoType result = solicitudPrestamoSvc.crearSolicitudPrestamo(solicitudPrestamoType);
			LOGGER.info("FINALIZA CREAR SOLICITUD PRESTAMO");
			return respuesta = SolicitudPrestamoValidator.validarResultadoaByCreate(result);
			
		}catch (ApplicationException e) {
			LOGGER.error("CREAR SOLICITUD PRESTAMO ->{}", e.getMessage());
			return respuesta = SolicitudPrestamoValidator.validarResultado(e);
			
		}catch (Exception e) {
			LOGGER.error("CREAR SOLICITUD PRESTAMO ->{}", e.getMessage());
			return respuesta =  new ResponseEntity<String>(MensajeDelSistema.ERROR_INTERNO, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@SuppressWarnings("unused")
	@Override
	public ResponseEntity<?> actualizarSolicitudPrestamo(@Valid SolicitudPrestamoType solicitudPrestamoType) {
		ResponseEntity<?> respuesta;
		try {
			LOGGER.info("INICIA ACTUALIZAR SOLICITUD PRESTAMO");
			SolicitudPrestamoType result = solicitudPrestamoSvc.actualizarSolicitudPrestamo(solicitudPrestamoType);
			LOGGER.info("FINALIZA ACTUALIZAR SOLICITUD PRESTAMO");
			return respuesta = SolicitudPrestamoValidator.validarResultadoaByUpdate(result);
		}catch (ApplicationException e) {
			LOGGER.error("ACTUALIZAR SOLICITUD PRESTAMO ->{}", e.getMessage());
			return respuesta = SolicitudPrestamoValidator.validarResultado(e);
			
		}catch (Exception e) {
			LOGGER.error("ACTUALIZAR SOLICITUD PRESTAMO ->{}", e.getMessage());
			return new ResponseEntity<RespuestaType>(
					new RespuestaType().codigoRespuesta("500").descripcion(MensajeDelSistema.ERROR_INTERNO),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public ResponseEntity<?> consultarSolicitudesPrestamo(String empresaId, @Valid @Min(1) Integer cantidadRegistros) {
		ResponseEntity<?> respuesta;
		try {
			LOGGER.info("INICIA LA CONSULTA DE SOLICITUDES PRESTAMO");

			List<SolicitudPrestamoType> solicitudesPrestamo = solicitudPrestamoSvc.consultarSolicitudesPrestamo(empresaId, cantidadRegistros);
			respuesta = SolicitudPrestamoValidator.validarResultado(solicitudesPrestamo);

		} catch (Exception e) {
			LOGGER.error("EXCEPCION CONSULTA DE SOLICITUDES PRESTAMO {}",e.getMessage());
			return new ResponseEntity<RespuestaType>(
					new RespuestaType().codigoRespuesta("500").descripcion(MensajeDelSistema.ERROR_INTERNO),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

		LOGGER.info("FINALIZA CONSULTA DE SOLICITUDES PRESTAMO");
		return respuesta;
	}

	@Override
	public ResponseEntity<?> consultarSolicitudesPrestamoPorFecha(String empresaId, Date fechaDesde, Date fechaHasta) {
		ResponseEntity<?> respuesta;
		try {
			LOGGER.info("INICIA LA CONSULTA DE SOLICITUDES PRESTAMO POR FECHA");
			List<SolicitudPrestamoType> solicitudesPrestamo = solicitudPrestamoSvc.consultarSolicitudesPrestamoPorFecha(empresaId, fechaDesde, fechaHasta);
			respuesta = SolicitudPrestamoValidator.validarResultado(solicitudesPrestamo);

		} catch (Exception e) {
			LOGGER.error("EXCEPCION CONSULTA DE SOLICITUDES PRESTAMO POR FECHA {}",e.getMessage());
			return new ResponseEntity<RespuestaType>(
					new RespuestaType().codigoRespuesta("500").descripcion(MensajeDelSistema.ERROR_INTERNO),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

		LOGGER.info("FINALIZA CONSULTA DE SOLICITUDES PRESTAMO POR FECHA {}", respuesta.getBody());
		return respuesta;
	}

	@Override
	public ResponseEntity<?> consultarSolicitudPrestamoPorEstado(EstadoSolicitud estadoSolicitud) {
		ResponseEntity<?> respuesta;
		try {
			LOGGER.info("INICIA LA CONSULTA DE SOLICITUDES PRESTAMO POR ESTADO");
			List<SolicitudPrestamoType> solicitudesPrestamo = solicitudPrestamoSvc.consultarSolicitudesPrestamoPorEstado(estadoSolicitud);
			respuesta = SolicitudPrestamoValidator.validarResultado(solicitudesPrestamo);

		} catch (Exception e) {
			LOGGER.error("EXCEPCION CONSULTA DE SOLICITUDES PRESTAMO POR ESTADO {}",e.getMessage());
			return new ResponseEntity<RespuestaType>(
					new RespuestaType().codigoRespuesta("500").descripcion(MensajeDelSistema.ERROR_INTERNO),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

		LOGGER.info("FINALIZA CONSULTA DE SOLICITUDES PRESTAMO POR ESTADO {}", respuesta.getBody());
		return respuesta;
	}

	@Override
	public ResponseEntity<?> consultarSolicitudPrestamoPorEmpleado(String empleadoId, String fechaDesde,
			String fechaHasta) {
		ResponseEntity<?>respuesta;
		LOGGER.info("INICIA LA CONSULTA DE SOLICITUDES PRESTAMO POR EMPLEADO");
		try {
			List<SolicitudPrestamoType>solicitudPrestamo = solicitudPrestamoSvc.consultarSolicitudPrestamoPorEmpleado(empleadoId, fechaDesde, fechaHasta);
			respuesta = SolicitudPrestamoValidator.validarResultado(solicitudPrestamo);
		} catch (Exception e) {
			LOGGER.info("ERROR EN CONSULTA DE SOLICITUDES PRESTAMO POR EMPLEADO {}", e.getMessage());
			return new ResponseEntity<RespuestaType>(
					new RespuestaType().codigoRespuesta("500").descripcion(MensajeDelSistema.ERROR_INTERNO),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		LOGGER.info("FINALIZA LA CONSULTA DE SOLICITUDES PRESTAMO POR EMPLEADO");
		return  respuesta;
	}
}
