package com.righttek.es.solicitudprestamo.utils;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.righttek.gotalent.comun.exception.ApplicationException;
import com.righttek.gotalent.comun.utilitarios.RespuestaType;
import com.righttek.gotalent.modelo_canonico.SolicitudPrestamoType;

public class SolicitudPrestamoValidator {
	/**
	 * VALIDAMOS EL CONTENIDO DEL RESULTADOS CUANDO ES LISTA PARA DEFINIR EL CONDIGO
	 * HTTP CORRESPONDIENTE
	 * 
	 * @param resultado
	 * @return
	 */
	public static final ResponseEntity<?> validarResultado(List<?> resultado) {
		if (resultado == null)
			return new ResponseEntity<>(new RespuestaType().codigoRespuesta("500")
					.descripcion("ALCO OCURRIO, NO PODIMOS OBTENER LO SOLICITADO"), HttpStatus.INTERNAL_SERVER_ERROR);
		if (resultado.isEmpty())
			return new ResponseEntity<>(
					new RespuestaType().codigoRespuesta("204").descripcion("NO SE ENCONTRARON RESULTADOS"),
					HttpStatus.NO_CONTENT);
		return ResponseEntity.ok(resultado);

	}

	/**
	 * VALIDAMOS EL CONTENIDO DEL RESULTADO CUANDO DE MANERA GENERAL PARA DEFINIR EL
	 * CODIGO HTTP CORRESPONDIENTE
	 * 
	 * @param resultado
	 * @return el dato de repuesta con el codigo Http correspondiente
	 */
	public static ResponseEntity<RespuestaType> validarResultado(Object resultado) {
		if (resultado == null) {
			return new ResponseEntity<>(
					new RespuestaType().codigoRespuesta("500").descripcion("LA SOLICITUD NO SE PROCESO EXITOSAMENTE"),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return ResponseEntity.ok(new RespuestaType().codigoRespuesta("200").descripcion("PROCESO EXITOSO"));
	}
	
	/**
	 * VALIDAMOS EL CONTENIDO DEL RESULTADO DE LA CONSULTA DE UNA SolicitudPrestamo DEFINIR EL
	 * CODIGO HTTP CORRESPONDIENTE
	 * 
	 * @param prestamo
	 * @return el dato de repuesta con el codigo Http correspondiente
	 */
	public static ResponseEntity<?> validarResultado(SolicitudPrestamoType prestamo) {
		if (prestamo == null) {
			return new ResponseEntity<>(
					new RespuestaType().codigoRespuesta("500").descripcion("LA SOLICITUD NO SE PROCESO EXITOSAMENTE"),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return ResponseEntity.ok(prestamo);
	}

	/**
	 * VALIDAMOS EL CONTENIDO DEL RESULTADO CUANDO ACTUALIZAMOS UNA SolicitudPrestamo PARA DEFINIR EL
	 * CODIGO HTTP Y EL MENSAJE CORREPONDIENTE CORRESPONDIENTE
	 * 
	 * @param resultado
	 * @return el dato de repuesta con el codigo Http correspondiente
	 */
	public static ResponseEntity<RespuestaType> validarResultadoaByUpdate(SolicitudPrestamoType resultado) {
		if (resultado == null) {
			return new ResponseEntity<>(
					new RespuestaType().codigoRespuesta("500").descripcion("El recurso no pudo ser actualizado"),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return ResponseEntity.ok(new RespuestaType().codigoRespuesta("200").descripcion("Recurso Actualizado"));
	}

	/**
	 * VALIDAMOS EL CONTENIDO DEL RESULTADO CUANDO CREAMOS UNA SolicitudPrestamo  PARA DEFINIR EL
	 * CODIGO HTTP CORRESPONDIENTE
	 * 
	 * @param resultado
	 * @return el dato de repuesta con el codigo Http correspondiente
	 */
	public static ResponseEntity<RespuestaType> validarResultadoaByCreate(SolicitudPrestamoType resultado) {
		if (resultado == null) {
			return new ResponseEntity<>(
					new RespuestaType().codigoRespuesta("500").descripcion("El recurso no pudo ser creado"),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return new ResponseEntity<>(
				new RespuestaType().codigoRespuesta("201")
						.descripcion(String.format("ID del recurso creado: [%s]", resultado.getId().toString())),
				HttpStatus.CREATED);
	}

	/**
	 * VALIDAMOS EL CONTENIDO DE UNA EXCEPCION DE NEGOCION  "ApplicationException" 
	 * PARA DEFINIR EL CODIGO HTTP CORRESPONDIENTE
	 * 
	 * @param ex
	 * @return el dato de repuesta con el codigo Http correspondiente
	 */
	public static ResponseEntity<RespuestaType> validarResultado(ApplicationException ex) {
		ResponseEntity<RespuestaType> respuesta;
		switch (ex.getError()) {
		case NO_ENCONTRADO:
			respuesta = new ResponseEntity<>(new RespuestaType().codigoRespuesta("404").descripcion(ex.getMessage()),
					HttpStatus.NOT_FOUND);
			break;
		case SOLICITUD_INVALIDA:
			respuesta = new ResponseEntity<>(new RespuestaType().codigoRespuesta("400").descripcion(ex.getMessage()),
					HttpStatus.BAD_REQUEST);
			break;
		case SERVICIO_INACCESIBLE:
			respuesta = new ResponseEntity<>(new RespuestaType().codigoRespuesta("502").descripcion(ex.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
			break;
		case FUENTE_DE_DATOS:
			respuesta = new ResponseEntity<>(new RespuestaType().codigoRespuesta("503").descripcion(ex.getMessage()),
					HttpStatus.SERVICE_UNAVAILABLE);
			break;
		default:
			respuesta = new ResponseEntity<>(new RespuestaType().codigoRespuesta("500").descripcion(ex.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
			break;
		}

		return respuesta;
	}
}
