package com.righttek.es.solicitudprestamo.repository.model;

import java.util.Date;
import java.util.Map;
import java.util.UUID;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Prestamo {
	
	private String aprobadoPor;
	
	@ElementCollection
	private Map<String, Double> desglosePago;
	
	private String empleadoId;
	
	private String estado;
	
	private Date fechaCreacion;
	
	private Date fechaFin;
	
	private Date fechaInicio;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private UUID id;
	
	private Double valorTotal;

	/**
	 * @return the aprobadoPor
	 */
	public String getAprobadoPor() {
		return aprobadoPor;
	}

	/**
	 * @param aprobadoPor the aprobadoPor to set
	 */
	public void setAprobadoPor(String aprobadoPor) {
		this.aprobadoPor = aprobadoPor;
	}

	

	/**
	 * @return the desglosePago
	 */
	public Map<String, Double> getDesglosePago() {
		return desglosePago;
	}

	/**
	 * @param desglosePago the desglosePago to set
	 */
	public void setDesglosePago(Map<String, Double> desglosePago) {
		this.desglosePago = desglosePago;
	}

	/**
	 * @return the empleadoId
	 */
	public String getEmpleadoId() {
		return empleadoId;
	}

	/**
	 * @param empleadoId the empleadoId to set
	 */
	public void setEmpleadoId(String empleadoId) {
		this.empleadoId = empleadoId;
	}

	/**
	 * @return the estado
	 */
	public String getEstado() {
		return estado;
	}

	/**
	 * @param estado the estado to set
	 */
	public void setEstado(String estado) {
		this.estado = estado;
	}

	/**
	 * @return the fechaCreacion
	 */
	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	/**
	 * @param fechaCreacion the fechaCreacion to set
	 */
	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	/**
	 * @return the fechaFin
	 */
	public Date getFechaFin() {
		return fechaFin;
	}

	/**
	 * @param fechaFin the fechaFin to set
	 */
	public void setFechaFin(Date fechaFin) {
		this.fechaFin = fechaFin;
	}

	/**
	 * @return the fechaInicio
	 */
	public Date getFechaInicio() {
		return fechaInicio;
	}

	/**
	 * @param fechaInicio the fechaInicio to set
	 */
	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	/**
	 * @return the id
	 */
	public UUID getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(UUID id) {
		this.id = id;
	}

	/**
	 * @return the valorTotal
	 */
	public Double getValorTotal() {
		return valorTotal;
	}

	/**
	 * @param valorTotal the valorTotal to set
	 */
	public void setValorTotal(Double valorTotal) {
		this.valorTotal = valorTotal;
	}
	
	
}
