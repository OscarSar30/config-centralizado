package com.righttek.es.solicitudprestamo.repository.model;


import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DiscriminatorOptions;

import com.righttek.gotalent.modelo_canonico.EstadoSolicitud;

/**
 * @author RGT_Capacitación_03
 * 
 *
 */
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(name = "dytype")
@DiscriminatorOptions(force = true)
@Table(name = "solicitud_base")
public class SolicitudBase implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Column(name = "empleado_aprobador_id")
	private String empleadoAprobadorId;
	
	@NotNull(message="{empleadoId.required}")
	@Column(name = "empleado_id")
	private String empleadoId;
	
	@NotNull(message="{empresaId.required}")
	@Column(name = "empresa_id")
	private String empresaId;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "estado")
	private EstadoSolicitud estado;
	
	@Column(name = "estado_flujo_aprobacion")
	private String estadoFlujoAprobacion;
	
	@Column(name = "fecha_creacion")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaCreacion;
	
	@Column(name = "fecha_modificacion")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaModificacion;
	
	@Column(name = "fecha_solicitud")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaSolicitud;
	
	@Id
	@Column(name = "id", unique = true)
	@GeneratedValue(strategy = GenerationType.AUTO)
	private UUID id;
	
	@Column(name = "justificacion")
	private String justificacion;
	
	@Column(name = "nombre_empleado")
	private String nombreEmpleado;
	
	@Column(name = "observacion")
	private String observacion;
	
	@NotNull(message="{tipo.required}")
	@Column(name = "tipo")
	private String tipo;
	
	@Column(name = "usuario_creacion")
	private String usuarioCreacion;
	
	@Column(name = "usuario_id")
	private String usuarioId;
	
	@Column(name = "usuario_modificacion")
	private String usuarioModificacion;

	/**
	 * @return the empleadoId
	 */
	public String getEmpleadoId() {
		return empleadoId;
	}

	/**
	 * @param empleadoId the empleadoId to set
	 */
	public void setEmpleadoId(String empleadoId) {
		this.empleadoId = empleadoId;
	}

	/**
	 * @return the empresaId
	 */
	public String getEmpresaId() {
		return empresaId;
	}

	/**
	 * @param empresaId the empresaId to set
	 */
	public void setEmpresaId(String empresaId) {
		this.empresaId = empresaId;
	}

	

	/**
	 * @return the estado
	 */
	public EstadoSolicitud getEstado() {
		return estado;
	}

	/**
	 * @param estado the estado to set
	 */
	public void setEstado(EstadoSolicitud estado) {
		this.estado = estado;
	}

	/**
	 * @return the estadoFlujoAprobacion
	 */
	public String getEstadoFlujoAprobacion() {
		return estadoFlujoAprobacion;
	}

	/**
	 * @param estadoFlujoAprobacion the estadoFlujoAprobacion to set
	 */
	public void setEstadoFlujoAprobacion(String estadoFlujoAprobacion) {
		this.estadoFlujoAprobacion = estadoFlujoAprobacion;
	}

	/**
	 * @return the fechaCreacion
	 */
	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	/**
	 * @param fechaCreacion the fechaCreacion to set
	 */
	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	/**
	 * @return the fechaModificacion
	 */
	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	/**
	 * @param fechaModificacion the fechaModificacion to set
	 */
	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	/**
	 * @return the fechaSolicitud
	 */
	public Date getFechaSolicitud() {
		return fechaSolicitud;
	}

	/**
	 * @param fechaSolicitud the fechaSolicitud to set
	 */
	public void setFechaSolicitud(Date fechaSolicitud) {
		this.fechaSolicitud = fechaSolicitud;
	}

	/**
	 * @return the id
	 */
	public UUID getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(UUID id) {
		this.id = id;
	}

	/**
	 * @return the tipo
	 */
	public String getTipo() {
		return tipo;
	}

	/**
	 * @param tipo the tipo to set
	 */
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	/**
	 * @return the usuarioCreacion
	 */
	public String getUsuarioCreacion() {
		return usuarioCreacion;
	}

	/**
	 * @param usuarioCreacion the usuarioCreacion to set
	 */
	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}

	/**
	 * @return the usuarioId
	 */
	public String getUsuarioId() {
		return usuarioId;
	}

	/**
	 * @param usuarioId the usuarioId to set
	 */
	public void setUsuarioId(String usuarioId) {
		this.usuarioId = usuarioId;
	}

	/**
	 * @return the usuarioModificacion
	 */
	public String getUsuarioModificacion() {
		return usuarioModificacion;
	}

	/**
	 * @param usuarioModificacion the usuarioModificacion to set
	 */
	public void setUsuarioModificacion(String usuarioModificacion) {
		this.usuarioModificacion = usuarioModificacion;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * @return the nombreEmpleado
	 */
	public String getNombreEmpleado() {
		return nombreEmpleado;
	}

	/**
	 * @param nombreEmpleado the nombreEmpleado to set
	 */
	public void setNombreEmpleado(String nombreEmpleado) {
		this.nombreEmpleado = nombreEmpleado;
	}

	/**
	 * @return the empleadoAprobadorId
	 */
	public String getEmpleadoAprobadorId() {
		return empleadoAprobadorId;
	}

	/**
	 * @param empleadoAprobadorId the empleadoAprobadorId to set
	 */
	public void setEmpleadoAprobadorId(String empleadoAprobadorId) {
		this.empleadoAprobadorId = empleadoAprobadorId;
	}

	/**
	 * @return the justificacion
	 */
	public String getJustificacion() {
		return justificacion;
	}

	/**
	 * @param justificacion the justificacion to set
	 */
	public void setJustificacion(String justificacion) {
		this.justificacion = justificacion;
	}

	/**
	 * @return the observacion
	 */
	public String getObservacion() {
		return observacion;
	}

	/**
	 * @param observacion the observacion to set
	 */
	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}
	
}