package com.righttek.es.solicitudprestamo.repository.contract;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.righttek.es.solicitudprestamo.repository.model.SolicitudPrestamo;
import com.righttek.gotalent.modelo_canonico.EstadoSolicitud;

@Repository
public interface ISolicitudPrestamoRepository extends JpaRepository<SolicitudPrestamo, UUID>{
	
	@Query (value = "select * from solicitud_base sb  \n" + 
			"				inner join solicitud_prestamo sp on sb.id = sp.id  \n" + 
			"				where sb.empresa_id = :empresaId and sb.dytype = 'SolicitudPrestamo' order by sb.fecha_creacion desc limit :cantidadRegistros", nativeQuery=true)
	public List<SolicitudPrestamo> consultarSolicitudesPrestamo(
			@Param ("empresaId") String empresaId, 
			@Param ("cantidadRegistros")Integer cantidadRegistros);
	
	@Query (value = "select * from solicitud_base sb \n" 
			+  "	inner join solicitud_prestamo sp on sb.id = sp.id \n" 
			+  "	where sb.empresa_id = :empresaId \n"
			+ "		and sb.dytype = 'SolicitudPrestamo'  "
			+  "    and sb. fecha_creacion \\:\\:DATE between :fechaDesde and :fechaHasta \\:\\:DATE \n"
			+  "	and sb.fecha_solicitud \\:\\:DATE between :fechaDesde and :fechaHasta \\:\\:DATE order by sb.fecha_creacion desc", nativeQuery=true)
	public List<SolicitudPrestamo> consultarSolicitudesPrestamoPorFecha(
			@Param ("empresaId") String empresaId, 
		    @Param ("fechaDesde") Date fechaDesde,
		    @Param ("fechaHasta") Date fechaHasta);
	
	
	@Query (value = "select * from solicitud_base sb \n" 
			+  "	inner join solicitud_prestamo sp on sb.id = sp.id \n" 
			+  "	where sb.dytype = 'SolicitudPrestamo' "
			+ "     and sb.estado = :#{#estadoSolicitud.name()} order by sb.fecha_creacion desc", nativeQuery=true)
	public List<SolicitudPrestamo> consultarSolicitudesPrestamoPorEstado(
			@Param ("estadoSolicitud") EstadoSolicitud estado);
	
	
	@Query(value = "select *from solicitud_base sb"
			+ " inner join solicitud_prestamo sp on sb.id= sp.id"
			+ "	where sb.empleado_id = :empleadoId"
			+ "	and sb.dytype = 'SolicitudPrestamo'"
			+ " and sb. fecha_creacion \\:\\:DATE between :fechaDesde and :fechaHasta \\:\\:DATE "
			+ "	and sb.fecha_solicitud \\:\\:DATE between :fechaDesde and :fechaHasta \\:\\:DATE order by sb.fecha_creacion desc"
			,nativeQuery = true)
	public List<SolicitudPrestamo>consultarSolicitudesPrestamoPorEmpleado(
			@Param("empleadoId")String empleadoId ,
			@Param("fechaDesde")Date fechaInicio,
			@Param("fechaHasta")Date fechaFin);
}
