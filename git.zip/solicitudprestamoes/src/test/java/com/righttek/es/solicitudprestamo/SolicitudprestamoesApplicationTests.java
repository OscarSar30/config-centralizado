package com.righttek.es.solicitudprestamo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SolicitudprestamoesApplicationTests {

	@Test
	void contextLoads() {
	}

}
