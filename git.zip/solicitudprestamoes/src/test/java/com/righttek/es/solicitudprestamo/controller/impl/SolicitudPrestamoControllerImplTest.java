package com.righttek.es.solicitudprestamo.controller.impl;


import java.io.File;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.righttek.es.solicitudprestamo.repository.contract.ISolicitudPrestamoRepository;
import com.righttek.es.solicitudprestamo.repository.model.SolicitudPrestamo;
import com.righttek.es.solicitudprestamo.utils.convert.SolicitudPrestamoConvert;
import com.righttek.gotalent.modelo_canonico.EstadoSolicitud;
import com.righttek.gotalent.modelo_canonico.SolicitudPrestamoType;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class SolicitudPrestamoControllerImplTest {
	
	@Autowired
	private MockMvc mockMvc;
	@Autowired
	private WebApplicationContext wac;
	@Autowired
	private ObjectMapper objectMapper;
	@Autowired
	private ISolicitudPrestamoRepository solicitudPrestamoRepository;
	
	
	private File datosJsonSolicitudPrestamo;

	@BeforeEach
	void setUp() throws Exception {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
		this.datosJsonSolicitudPrestamo = new File("src/test/resources/solicitudPrestamo.json");
	}

	@AfterEach
	void tearDown() throws Exception {
		this.datosJsonSolicitudPrestamo = null;
		this.mockMvc = null;
	}
	
	/**
	 * crarSolicitudPrestamo
	 * VALIDAMOS EL ESCENARIO DE UNA CREACION SOLICITUD PRESTAMO EXITOSA
	 * @throws Exception 
	 * @throws JsonProcessingException 
	 */
	@Test
	void testCrearSolicitudPrestamo() throws JsonProcessingException, Exception {
		
		SolicitudPrestamoType solicitudPrestamoType = objectMapper.readValue(datosJsonSolicitudPrestamo, new TypeReference<List<SolicitudPrestamoType>>() {}).get(0);
		this.mockMvc.perform(MockMvcRequestBuilders
				.post("/api/es/solicitud/prestamo/v1")
				.content(objectMapper.writeValueAsString(solicitudPrestamoType))
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON))
				.andDo(MockMvcResultHandlers.print())
				.andExpect(MockMvcResultMatchers.status().isCreated());
		
		
	}
	
	/**
	 * actualizarSolicitudPrestamo
	 * VALIDAMOS EL ESCENARIO DE UNA ACTUALIZACION SOLICITUD PRESTAMO EXITOSA
	 * @throws Exception 
	 * @throws JsonProcessingException 
	 */
	
	@Test
	void testActualizarSolicitudPrestamo() throws JsonProcessingException, Exception {
		SolicitudPrestamoType solicitudPrestamoType = objectMapper.readValue(datosJsonSolicitudPrestamo, new TypeReference<List<SolicitudPrestamoType>>() {}).get(0);
		SolicitudPrestamo solicitudPrestamo = solicitudPrestamoRepository.save(SolicitudPrestamoConvert.typeToModel(solicitudPrestamoType));
		solicitudPrestamoType.setId(solicitudPrestamo.getId());
		solicitudPrestamoType.getPrestamo().setId(solicitudPrestamo.getPrestamo().getId());
		
		solicitudPrestamoType.setEstado(EstadoSolicitud.APROBADA);
		
		this.mockMvc.perform(MockMvcRequestBuilders
				.put("/api/es/solicitud/prestamo/v1")
				.content(objectMapper.writeValueAsString(solicitudPrestamoType))
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON))
	      		.andDo(MockMvcResultHandlers.print())
				.andExpect(MockMvcResultMatchers.status().isOk());
		
	}

	
	/**
	 * VALIDAMOS EL ESCENARIO DE UNA ACTUALIZACION SOLICITUD PRESTAMO RECURSO NO ENCONTRADO
	 * @throws Exception 
	 * @throws JsonProcessingException 
	 */

	@Test
	void testActualizarSolicitudPrestamoRecursoNoEncontrado() throws JsonProcessingException, Exception {
		SolicitudPrestamoType solicitudPrestamoType = objectMapper.readValue(datosJsonSolicitudPrestamo, new TypeReference<List<SolicitudPrestamoType>>() {}).get(0);
		solicitudPrestamoRepository.save(SolicitudPrestamoConvert.typeToModel(solicitudPrestamoType));
		UUID random = UUID.randomUUID();
		solicitudPrestamoType.setId(random);
		solicitudPrestamoType.setEstado(EstadoSolicitud.APROBADA);
		
		
		this.mockMvc.perform(MockMvcRequestBuilders
				.put("/api/es/solicitud/prestamo/v1")
				.content(objectMapper.writeValueAsString(solicitudPrestamoType))
				.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON))
	      		.andDo(MockMvcResultHandlers.print())
				.andExpect(MockMvcResultMatchers.status().isNotFound());
	}
	
	/**
	 * VALIDAMOS EL ESCENARIO DE UNA CONSULTA POR EMPRESA ID, Y POR CANTIDAD DE REGISTROS EXITOSO
	 * @throws Exception 
	 * @throws JsonProcessingException 
	 */
	@Test
	void testConsultarSolicitudesPrestamo() throws JsonProcessingException, Exception {
		List<SolicitudPrestamoType> solicitudPrestamo = objectMapper.readValue(datosJsonSolicitudPrestamo, new TypeReference<List<SolicitudPrestamoType>>() {});
		solicitudPrestamoRepository.saveAll(SolicitudPrestamoConvert.listTypeToModel(solicitudPrestamo));
		String empresaId = "1004";
		Integer cantidadRegistros = 10;
		 
		this.mockMvc.perform(MockMvcRequestBuilders
				.get("/api/es/solicitud/prestamo/v1/{empresaId}/{cantidadRegistros}",empresaId, cantidadRegistros)
				.accept(MediaType.APPLICATION_JSON))
				.andDo(MockMvcResultHandlers.print())
				.andExpect(MockMvcResultMatchers.status().isOk());
		
	}
	/**
	 * VALIDAMOS EL ESCENARIO DE UNA CONSULTA POR EMPRESA ID, Y POR CANTIDAD DE REGISTROS NO CONTENT
	 * @throws Exception 
	 * @throws JsonProcessingException 
	 */
	@Test
	void testConsultarSolicitudesPrestamoNoContent() throws JsonProcessingException, Exception {
		List<SolicitudPrestamoType> solicitudPrestamo = objectMapper.readValue(datosJsonSolicitudPrestamo, new TypeReference<List<SolicitudPrestamoType>>() {});
		solicitudPrestamoRepository.saveAll(SolicitudPrestamoConvert.listTypeToModel(solicitudPrestamo));
		String empresaId = "9999";
		Integer cantidadRegistros = 10;
		 
		this.mockMvc.perform(MockMvcRequestBuilders
				.get("/api/es/solicitud/prestamo/v1/{empresaId}/{cantidadRegistros}",empresaId, cantidadRegistros)
				.accept(MediaType.APPLICATION_JSON))
				.andDo(MockMvcResultHandlers.print())
				.andExpect(MockMvcResultMatchers.status().isNoContent());
		
	}
	
	/**
	 * VALIDAMOS EL ESCENARIO DE UNA CONSULTA POR ESTADO SOLICITUD EXITOSO
	 * @throws Exception 
	 * @throws JsonProcessingException 
	 */
	
	@Test
	void testConsultarSolicitudPrestamoPorEstado() throws JsonProcessingException, Exception {
		List<SolicitudPrestamoType> solicitudPrestamo = objectMapper.readValue(datosJsonSolicitudPrestamo, new TypeReference<List<SolicitudPrestamoType>>() {});
		solicitudPrestamoRepository.saveAll(SolicitudPrestamoConvert.listTypeToModel(solicitudPrestamo));
		EstadoSolicitud estadoSolicitud =EstadoSolicitud.PENDIENTE;
		 
		this.mockMvc.perform(MockMvcRequestBuilders
				.get("/api/es/solicitud/prestamo/estado/v1/{estadoSolicitud}", estadoSolicitud)
				.accept(MediaType.APPLICATION_JSON))
				.andDo(MockMvcResultHandlers.print())
				.andExpect(MockMvcResultMatchers.status().isOk());
		
	}
	
	/**
	 * VALIDAMOS EL ESCENARIO DE UNA CONSULTA POR ESTADO SOLICITUD NO CONTENT
	 * @throws Exception 
	 * @throws JsonProcessingException 
	 */
	@Test
	void testConsultarSolicitudPrestamoPorEstadoNoContent() throws JsonProcessingException, Exception {
		List<SolicitudPrestamoType> solicitudPrestamo = objectMapper.readValue(datosJsonSolicitudPrestamo, new TypeReference<List<SolicitudPrestamoType>>() {});
		solicitudPrestamoRepository.saveAll(SolicitudPrestamoConvert.listTypeToModel(solicitudPrestamo));
		EstadoSolicitud estadoSolicitud =EstadoSolicitud.RECHAZADA;
		 
		this.mockMvc.perform(MockMvcRequestBuilders
				.get("/api/es/solicitud/prestamo/estado/v1/{estadoSolicitud}", estadoSolicitud)
				.accept(MediaType.APPLICATION_JSON))
				.andDo(MockMvcResultHandlers.print())
				.andExpect(MockMvcResultMatchers.status().isNoContent());
		
	}
	
	/**
	 * VALIDAMOS EL ESCENARIO DE UNA CONSULTA POR EMPRESA ID Y POR RANGO DE FECHA SOLICITUD EXITOSO
	 * @throws Exception 
	 * @throws JsonProcessingException 
	 */
	
	@Test
	void testConsultarSolicitudesPrestamoPorFecha() throws JsonProcessingException, Exception {
		List<SolicitudPrestamoType> solicitudPrestamo = objectMapper.readValue(datosJsonSolicitudPrestamo, new TypeReference<List<SolicitudPrestamoType>>() {});
		solicitudPrestamoRepository.saveAll(SolicitudPrestamoConvert.listTypeToModel(solicitudPrestamo));
		String empresaId = "1004";
		String fechaDesde = "2021-01-01";
		String fechaHasta = "2021-02-15";
		 
		this.mockMvc.perform(MockMvcRequestBuilders
				.get("/api/es/solicitud/prestamo/fecha/v1/{empresaId}/{fechaDesde}/{fechaHasta}",empresaId,fechaDesde, fechaHasta)
				.accept(MediaType.APPLICATION_JSON))
				.andDo(MockMvcResultHandlers.print())
				.andExpect(MockMvcResultMatchers.status().isOk());
		
	}
	
	/**
	 * VALIDAMOS EL ESCENARIO DE UNA CONSULTA POR EMPRESA ID Y POR RANGO DE FECHA SOLICITUD NO CONTENT
	 * @throws Exception 
	 * @throws JsonProcessingException 
	 */
	
	@Test
	void testConsultarSolicitudesPrestamoPorFechaNoContent() throws JsonProcessingException, Exception {
		List<SolicitudPrestamoType> solicitudPrestamo = objectMapper.readValue(datosJsonSolicitudPrestamo, new TypeReference<List<SolicitudPrestamoType>>() {});
		solicitudPrestamoRepository.saveAll(SolicitudPrestamoConvert.listTypeToModel(solicitudPrestamo));
		String empresaId = "101400000000";
		String fechaDesde = "2020-10-21";
		String fechaHasta = "2020-10-21";
		 
		this.mockMvc.perform(MockMvcRequestBuilders
				.get("/api/es/solicitud/prestamo/fecha/v1/{empresaId}/{fechaDesde}/{fechaHasta}",empresaId,fechaDesde, fechaHasta)
				.accept(MediaType.APPLICATION_JSON))
				.andDo(MockMvcResultHandlers.print())
				.andExpect(MockMvcResultMatchers.status().isNoContent());
		
	}
	
	/**
	 * VALIDAMOS EL ESCENARIO DE UNA CONSULTA POR EMPRESA ID Y POR RANGO DE FECHA SOLICITUD EXITOSO
	 * @throws Exception 
	 * @throws JsonProcessingException 
	 */
	
	@Test
	void testConsultarSolicitudesPrestamoPorEmpleado() throws JsonProcessingException, Exception {
		List<SolicitudPrestamoType> solicitudPrestamo = objectMapper.readValue(datosJsonSolicitudPrestamo, new TypeReference<List<SolicitudPrestamoType>>() {});
		solicitudPrestamoRepository.saveAll(SolicitudPrestamoConvert.listTypeToModel(solicitudPrestamo));
		String empleadoId = "1001";
		String fechaDesde = "2021-01-01";
		String fechaHasta = "2021-02-15";
		 
		this.mockMvc.perform(MockMvcRequestBuilders
				.get("/api/es/solicitud/prestamo/empleado/fecha/v1/{empleadoId}/{fechaDesde}/{fechaHasta}",empleadoId,fechaDesde, fechaHasta)
				.accept(MediaType.APPLICATION_JSON))
				.andDo(MockMvcResultHandlers.print())
				.andExpect(MockMvcResultMatchers.status().isOk());
		
	}
	
	
	/**
	 * VALIDAMOS EL ESCENARIO DE UNA CONSULTA POR EMPRESA ID Y POR RANGO DE FECHA SOLICITUD NOT CONTENT
	 * @throws Exception 
	 * @throws JsonProcessingException 
	 */
	
	@Test
	void testConsultarSolicitudesPrestamoPorEmpleadoNOCONTENT() throws JsonProcessingException, Exception {
		List<SolicitudPrestamoType> solicitudPrestamo = objectMapper.readValue(datosJsonSolicitudPrestamo, new TypeReference<List<SolicitudPrestamoType>>() {});
		solicitudPrestamoRepository.saveAll(SolicitudPrestamoConvert.listTypeToModel(solicitudPrestamo));
		String empleadoId = "1003";
		String fechaDesde = "2021-01-01";
		String fechaHasta = "2021-02-15";
		 
		this.mockMvc.perform(MockMvcRequestBuilders
				.get("/api/es/solicitud/prestamo/empleado/fecha/v1/{empleadoId}/{fechaDesde}/{fechaHasta}",empleadoId,fechaDesde, fechaHasta)
				.accept(MediaType.APPLICATION_JSON))
				.andDo(MockMvcResultHandlers.print())
				.andExpect(MockMvcResultMatchers.status().isNoContent());
		
	}
	
	
	
	
}
